public class SumIterative{
    public static int Sum(int n){
     int s = 0; 
     for (int i=0; i<=n; i++){
         s = s + i; 
     }
     return s; 
    }
    public static void main(String[] args){
       System.out.println(Sum(10)); 
    }
}
