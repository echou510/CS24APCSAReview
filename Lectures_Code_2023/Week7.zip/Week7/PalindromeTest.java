import java.util.Scanner;
public class PalindromeTest
{
    //main function
     public static void main(String[] args){
         //Scanner function
        Scanner input = new Scanner(System.in);
        boolean done = false;
        //while loop
        while(!done){
            System.out.println("Please enter a String or a Word: ");
            String word = input.nextLine();
            Palindrome rp = new Palindrome();
            System.out.println(rp.isPalindrome(word));
            System.out.println("Do you want to continue(Y/N)? ");
            String yes = input.nextLine();
            //if loop
            if(yes.length()!= 0 && (yes.charAt(0)=='Y' || yes.charAt(0)== 'y')) done = false;
            else done = true;
        }
    }
    
}
