public class BaseballRunner{
   public static void main(String[] args){
      BaseballPlayer[] roster = {
          new BaseballPlayer("Eric Kratz",     2, 2),
          new BaseballPlayer("Miguel Andujar", 7,4),
          new BaseballPlayer("Michael Pineda", 3,1),
          new BaseballPlayer("Garrett Cooper", 43,14),
          new BaseballPlayer("Starlin Castro", 443,133),
          new BaseballPlayer("Ronald Torreyes", 315,92),
          new BaseballPlayer("Didi Gregorius", 534,154),
          new BaseballPlayer("Aaron Judge", 542,154),
          new BaseballPlayer("Gary Sanchez", 471,131),
          new BaseballPlayer("Chase Headley", 512,140),
          new BaseballPlayer("Ji-Man Choi", 15,4),
          new BaseballPlayer("Aaron Hicks", 301,80),
          new BaseballPlayer("Brett Gardner", 594,157),
          new BaseballPlayer("Jacoby Ellsbury", 356,94),
          new BaseballPlayer("Mason Williams", 16,4),
          new BaseballPlayer("Clint Frazier", 134,31),
          new BaseballPlayer("Matt Holliday", 373,86),
          new BaseballPlayer("Tyler Austin", 40,9),
          new BaseballPlayer("Todd Frazier", 194,43),
          new BaseballPlayer("Austin Romine", 229,50),
          new BaseballPlayer("Chris Carter", 184,37),
          new BaseballPlayer("Luis Severino", 5,1),
        };
      System.out.println("Players: "+roster.length+" Batting Average:"+findTeamAverage(roster)); 
      System.out.println("Best Player: "+findBestPlayer(roster)); 
    }
   
   public static String findBestPlayer(BaseballPlayer[] arr){
         String bestPlayer="";
         double maxBA = Double.MIN_VALUE; 
         for (int i=0; i<arr.length; i++){
               if (arr[i].getBattingAverage() > maxBA){
                   maxBA = arr[i].getBattingAverage(); 
                   bestPlayer = arr[i].getName(); 
                }
            }
         return bestPlayer; 
    }
    
   public static double findTeamAverage(BaseballPlayer[] arr){
       int atBats=0; 
       int hits=0; 
       for (BaseballPlayer b: arr){
           atBats += b.getAtBats(); 
           hits += b.getHits(); 
        } 
       return (double) hits/atBats;  
    }
}


       
       