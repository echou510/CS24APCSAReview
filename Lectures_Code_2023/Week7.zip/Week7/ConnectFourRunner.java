public class ConnectFourRunner{
     public static void main(String[] args){
           int[][] board = {
             {0, 0, 0, 0, 0, 0, 0}, 
             {0, 0, 0, 0, 2, 1, 0}, 
             {0, 0, 2, 0, 1, 2, 0}, 
             {1, 0, 1, 2, 1, 1, 0}, 
             {2, 2, 1, 2, 2, 2, 1}, 
             {1, 1, 2, 1, 2, 2, 1}
            }; 
           int[][] board1 = {
             {0, 0, 0, 0, 0, 0, 0}, 
             {0, 0, 0, 0, 2, 1, 0}, 
             {0, 0, 1, 1, 1, 1, 0}, 
             {1, 0, 1, 2, 1, 1, 0}, 
             {2, 2, 1, 2, 2, 2, 1}, 
             {1, 1, 2, 1, 2, 2, 1}
            }; 
           System.out.println("Board Winner:" + checkForWinner(board)); 
           System.out.println("Board1 Winner:" + checkForWinner(board1)); 
        }
     public static int checkForWinner(int[][] board){ 
         // Horizontal check
         for (int i=0; i<board.length; i++){
              for (int j=0; j<board[i].length-3; j++){
                   if (
                    board[i][j] != 0 && board[i][j]==board[i][j+1] &&
                    board[i][j]==board[i][j+2] && board[i][j]==board[i][j+3] 
                   ) return board[i][j]; 
                }
            }
         // Vertical check
         for (int i=0; i<board.length-3; i++){
              for (int j=0; j<board[i].length; j++){
                   if (
                    board[i][j] != 0 && board[i][j]==board[i+1][j] &&
                    board[i][j]==board[i+2][j] && board[i][j]==board[i+3][j] 
                   ) return board[i][j]; 
                }
            }
         // slash check
         for (int i=0; i<board.length-3; i++){
              for (int j=3; j<board[i].length; j++){
                   if (
                    board[i][j] != 0 && board[i][j]==board[i+1][j-1] &&
                    board[i][j]==board[i+2][j-2] && board[i][j]==board[i+3][j-3] 
                   ) return board[i][j]; 
                }
            }
         // back slash check
         for (int i=0; i<board.length-3; i++){
              for (int j=0; j<board[i].length-3; j++){
                   if (
                    board[i][j] != 0 && board[i][j]==board[i+1][j+1] &&
                    board[i][j]==board[i+2][j+2] && board[i][j]==board[i+3][j+3] 
                   ) return board[i][j]; 
                }
            }
         return 0; 
        }
     
}


