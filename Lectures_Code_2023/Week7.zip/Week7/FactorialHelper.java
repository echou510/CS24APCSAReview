public class FactorialHelper{
    public static int f_helper(int n, int product){
      if (n==0) return product; 
      return f_helper(n-1, product * n); 
    }
    public static int f(int n){ return f_helper(5, 1);}
    public static void main(String[] args){ 
        System.out.println(f(5)); 
    }
}


