public class SumBackward{
   public static int Sum(int n, int sum){
      if (n==0) return sum;      
      return Sum(n-1, sum+n); 
    }
   public static int Sum(int n){ return Sum(n, 0); }
   public static void main(String[] args){
      System.out.println(Sum(10)); 
    }
}


