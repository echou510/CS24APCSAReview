public class Student
{
  private double GPA; 
  private String name; 
  Student(String n, double g){
      name = n; 
      GPA = g; 
    }
  public double getGPA(){  return GPA; }
  public String getName(){ return name; }
  public String toString(){return "{"+name+","+GPA+"}"; }; 
}

