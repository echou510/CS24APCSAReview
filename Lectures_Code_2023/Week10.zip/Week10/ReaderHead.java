public class ReaderHead{
   private int max = 0;
   private int index =0; 
   private boolean right=true; 
   ReaderHead(){}
   ReaderHead(int max){
      this.max = max; 
      index = 0; 
      right = true; 
    }
   public int getIndex(){ return index; }
   public void changeDirection(){
      right = !right; 
    }
   public boolean isFacingRight(){
       return right; 
    }
   public void move(int n){
      if (isFacingRight()){
         while (index<max-1 && n>0) { index++; n--; } 
        }
      else{
         while (index>0 && n>0) { index--; n--; } 
        }
    }
   public void reset(){
      if (isFacingRight()){ changeDirection(); }
      move(getIndex()); 
      changeDirection(); 
    }
   public void next(){
      if (isFacingRight() && getIndex()== max-1){
           changeDirection(); 
           move(1); 
           return; 
        }
      if (!isFacingRight() && getIndex()==0){
           changeDirection(); 
           move(1); 
           return; 
        }
      move(1); 
    }
}
