import java.util.ArrayList; 
import java.util.Arrays; 
public class WashingtonHigh
{
   public static ArrayList<Student> getSummerClass(ArrayList<Student> alist){
      ArrayList<Student> summer = new ArrayList<Student>();    
      for (int i=alist.size()-1; i>=0; i--){
          if (alist.get(i).getGPA() < 2.0){ 
               summer.add(alist.remove(i));
            }
        }
      //System.out.println("Student List: \n"+alist); 
      return summer; 
    }
   public static void main(String[] args){
      ArrayList<Student> slist = new ArrayList<Student>(
        Arrays.asList( new Student[]{
         new Student("Amy", 2.85), new Student("Bryan", 3.6), new Student("Carol", 1.46), 
         new Student("David", 4.0), new Student("Ellie", 1.98), new Student("Fanny", 3.2), 
         new Student("Goerge", 1.65), new Student("Harry", 2.78), new Student("Ivan", 2.95), 
         new Student("Jack", 1.8), new Student("Kate", 3.3), new Student("Larry", 2.25), 
         new Student("Mary", 2.03), new Student("Nancy", 1.77), new Student("Omar", 3.6), 
         new Student("Peter", 2.66), new Student("Queen", 1.99), new Student("Robert", 3.98) 
        })
      ); 
      System.out.println(getSummerClass(slist)); 
    }
}
