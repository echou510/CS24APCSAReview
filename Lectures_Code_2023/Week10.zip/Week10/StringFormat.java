public class StringFormat
{                   //0123456789012345678901
   static String a = "It is a wonderful day!"; 
   
   public static String leftAlignment(String str, int formatLength){
      String s = str; 
      for (int i=0; i<formatLength-str.length(); i++) { s += " ";}
      return s;
    }
   public static String rightAlignment(String str, int formatLength){
      String s = ""; 
      for (int i=0; i<formatLength-str.length(); i++) { s += " ";}
      s += str; 
      return s;
    }
   public static String centered(String str, int formatLength){
      String s = "";
      int left = (formatLength -str.length())/2; 
      int right = (formatLength -str.length())-left; 
      for (int i=0; i<left; i++) { s += " "; }
      s += str; 
      for (int i=0; i<right; i++) { s += " ";}
      return s;
    }
   public static String justified(String str, int formatLength){
       String s=""; 
       String[] tokens = str.split(" ");
       if (tokens.length == 0) return leftAlignment(s, formatLength);
       if (tokens.length == 1) return centered(s, formatLength); 
       int total=0; 
       for (int i=0; i<tokens.length; i++){
           tokens[i] = tokens[i].trim(); 
           total += tokens[i].length();
        }
       int gap = (formatLength-total)/(tokens.length-1); 
       int leftover = (formatLength-total)%(tokens.length-1); 
       s = tokens[0];
       for (int i=1; i<tokens.length; i++){
           if (leftover >0) {s+= " "; leftover--; }
           for (int j=0; j<gap; j++) s+= " "; 
           s += tokens[i];
        }
       return s; 
    }
   public static void main(String[] args){
      System.out.print("\f"); 
      System.out.println("          1         2         3         4");
      System.out.println("01234567890123456789012345678901234567890");
      System.out.println(leftAlignment(a,30)+"$");
      System.out.println(rightAlignment(a,30)+"$");
      System.out.println(centered(a,30)+"$");
      System.out.println(justified(a,30)+"$");
    }
}
