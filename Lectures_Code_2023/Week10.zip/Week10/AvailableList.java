import java.util.ArrayList; 
public class AvailableList
{
  static int[] data = {3, 5, 6, 1, 2, 7, 9, 0, 8}; 
  
  public static ArrayList<Integer> selectionSort(int[] data){
       ArrayList<Integer> a = new ArrayList<Integer>(); 
       boolean[] b = new boolean[data.length]; 
       for (int i=0; i<b.length; i++) b[i] = true; 
       for (int i=0; i<data.length; i++){
          int min = Integer.MAX_VALUE;
          int index = -1; 
          for (int j=0; j<data.length; j++){
              if (b[j]){
                  if (data[j] <min) 
                  { min = data[j]; 
                    index = j; 
                  }
                }
            }
          b[index] = false; 
          a.add(min); 
        } 
       return a; 
    }
  public static void main(String[] args){
      ArrayList<Integer> sorted = selectionSort(data); 
      System.out.println(sorted); 
    }
}
