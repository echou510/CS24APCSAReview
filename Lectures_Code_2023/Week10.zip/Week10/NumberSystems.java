import java.util.ArrayList; 
public class NumberSystems
{
  public static int reverse(int x){
      if (x==0) return 0; 
      int r=0; 
      while (x>0){
           int d = x % 10; 
           r = r*10 + d; 
           x /= 10; 
        }
      return r; 
    }
  public static int countZero(int x){
      if (x==0) return 1; 
      int c=0; 
      while (x>0){
           int d = x % 10; 
           if(d==0) c++; 
           x /= 10; 
        }
      return c; 
    }
  public static ArrayList<Integer> makeList(int x){
      ArrayList<Integer> alist = new ArrayList<Integer>();
      if (x==0) { alist.add(0); return alist; }
      while (x>0){
           int d = x % 10; 
           alist.add(d); 
           x /= 10; 
        }
      return alist; 
    }
  public static int sum(int x){
      if (x==0) return 0; 
      int sum =0; 
      while (x>0){
           int d = x % 10; 
           sum += d; 
           x /= 10; 
        }
      return sum; 
    }
  public static void main(String[] args){
      int a=0, b=12345, c=1010101; 
      System.out.print("\f");
      System.out.println("C1 Part (a):");
      System.out.println(" reverse(0)="+reverse(a)); 
      System.out.println(" reverse(12345)="+reverse(b)); 
      System.out.println(" reverse(1010101)="+reverse(c)); 
      System.out.println("C1 Part (b):");
      System.out.println(" countZero(0)="+countZero(a)); 
      System.out.println(" countZero(12345)="+countZero(b)); 
      System.out.println(" countZero(1010101)="+countZero(c)); 
      System.out.println("C1 Part (c):");
      System.out.println(" makeList(0)="+makeList(a)); 
      System.out.println(" makeList(12345)="+makeList(b)); 
      System.out.println(" makeList(1010101)="+makeList(c)); 
      System.out.println("C1 Part (d):");
      System.out.println(" sum(0)="+sum(a)); 
      System.out.println(" sum(12345)="+sum(b)); 
      System.out.println(" sum(1010101)="+sum(c)); 
    }
}
