public class BinaryToggler
{
    boolean t=false; 
    BinaryToggler(boolean x){t = x;}
    public void next(){
       t = !t; 
    }
    public boolean get(){
        return t; 
    }
    public String toString(){ return ""+t;}
    
    public static void main(String[] args){
        BinaryToggler bt = new BinaryToggler(true);
        for (int i=0; i<10; i++){
            System.out.println(bt); 
            bt.next(); 
        }
    }
}


