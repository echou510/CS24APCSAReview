public class Hotel{
   private int num; 
   private int available; 
   private boolean[] alist; 
   Hotel(int num){
      this.num  = num; 
      available = num; 
      alist = new boolean[num]; 
      for (int i=0; i<alist.length; i++) alist[i]=true; 
    }
   public boolean isAvailable(int n){
      if (n<num && alist[n]) return true; 
      return false; 
    }
   public boolean isFull(){ return available <=0; }
   public void checkIn(int n){
      if (isAvailable(n)) {
          alist[n] = false; 
          available--; 
        }
    }
   public void checkOut(int n){
      if (!isAvailable(n)) {
          alist[n] = true; 
          available++; 
        }
    }
   public String toString(){
      String str = "["; 
      for (int i=0; i<alist.length; i++){
          if (i==0) if (alist[i]) str += "T";  else str += "F"; 
          if (i!=0) if (alist[i]) str += " T"; else str += " F"; 
          if (i== alist.length-1) str += "]";
          if (i%10== 9 || i== alist.length-1) str += "\n"; 
        }
      return str; 
    }
}
