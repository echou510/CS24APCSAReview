public class ShortestDistance
{
   static Point[] alist = {
       new  Point(0.0, 0.0), new Point(1.0, 3.0),
       new  Point(-1.2, -1.0), new Point(-2.0, 0.5), 
       new  Point(4.0, 0.0), new Point(3.0, -3.0),
       new  Point(-5.1, 1.0), new Point(-0.2, 3.5)
    }; 
   static public class Point{
      double x=0; 
      double y=0;
      Point(double a, double b){
           x=a; 
           y=b; 
        }
    }
   static public class Pair{
      int p1=0; 
      int p2=0;
      Pair(int a, int b){
           p1=a; 
           p2=b; 
        }
    }
   public static double distance(Point a, Point b){
       return Math.sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)); 
    }
    
   public static void main(String[] args){
       Pair min = new Pair(0, 1); 
       double min_distance = distance(alist[0], alist[1]); 
       for (int i=0; i<alist.length-1; i++){
          for (int j=i+1; j<alist.length; j++){
                double dist = distance(alist[i], alist[j]);
                if (dist < min_distance){
                  min_distance = dist; 
                  min = new Pair(i,j); 
                }
            }
        } 
       System.out.println("Minimum Distance="+min_distance+
            " is between Point["+min.p1+"] and Point["+min.p2+"]"); 
    }
}
