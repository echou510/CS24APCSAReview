
public class TestHotel
{
  public static void main(String[] args){
      Hotel h = new Hotel(20); 
      System.out.print("\f"); 
      System.out.println("Initialized"); 
      System.out.print(h); 
      h.checkIn(3); 
      h.checkIn(6); 
      h.checkIn(7); 
      System.out.println("After check-ins"); 
      System.out.print(h); 
      h.checkOut(15); 
      h.checkOut(6); 
      h.checkOut(3); 
      System.out.println("After check-outs"); 
      System.out.print(h); 
    }
}
