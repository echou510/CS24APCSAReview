public class InverseCount
{
    static int[] a = {1,4, 3, 2, 5};
    public static int inverseCount(int[] x){    
       int count = 0; 
       for (int i=1; i<x.length; i++){
          for (int j=0; j<i; j++){
               if (x[i]<x[j]) count++; 
            }
        }
       return count; 
    }
   
   public static void main(String[] args){
      System.out.println("inverseCount(a)="+inverseCount(a));  
   }
}

