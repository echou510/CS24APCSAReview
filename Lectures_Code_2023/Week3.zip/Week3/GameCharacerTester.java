import java.util.ArrayList; 
import java.util.List; 
public class GameCharacerTester{
   public static void main(String[] args){
       GameCharacter character1 = new Bird(); 
       GameCharacter character2 = new Fish(); 
       List<GameCharacter> team = new ArrayList<GameCharacter>(); 
       team.add(character1); team.add(character2);
       for (GameCharacter character: team){
          System.out.println(character.move()); 
        }
    }
}
