public class Fish extends GameCharacter{
    public String move(){ return "I swim"; }
}
