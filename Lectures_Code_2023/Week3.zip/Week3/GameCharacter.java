public abstract class GameCharacter{
  public String sayHello(){ return "Hello"; }
  public abstract String move(); 
}


