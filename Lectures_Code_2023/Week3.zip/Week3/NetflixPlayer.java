public interface NetflixPlayer{
  String play(); 
  String pause();   // data field must be fianl static (constant)
  String rewind();  // public static by default
}
