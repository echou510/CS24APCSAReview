
public class LP4_FlagLoop
{
    public static int first_search(String str, char c){
      int ret = -1; 
      boolean found = false; // flag/sentinel
      
      for (int i=0; i< str.length() && !found; i++){ // index loop
            if (c == str.charAt(i)) {
              ret = i; 
              found = true; 
            }
        }
        
      return ret;  // default -1  
    }
     public static int last_search(String str, char c){
      int ret = -1; 
      int i=0; 
      while (i< str.length()){ // index loop
            if (c == str.charAt(i)) {
              ret = i; 
            }
          i++; 
        }
        
      return ret;  // default -1  
    }   
    public static void main(String[] args){
         System.out.print("\f"); 
                                        //01234567890123456789012345678901234567890123456789
         System.out.println(first_search("Welcome to Java a a  a a a  a a  a a ", 'a'));
         System.out.println(last_search( "Welcome to Java a a  a a a  a a  a a ", 'a')); 
    }
}
