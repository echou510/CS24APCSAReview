public class ReverseDigits
{
   public static int reverseDigit(int x){
       int r=0; 
       int d=0;
       while (x>0){
           d = x % 10; 
           r = r * 10 + d; 
           x /= 10; 
        } 
       return r; 
    }
   public static void main(String[] args){
       System.out.print("\f"); 
       System.out.println(reverseDigit(12345)); 
    }
}
