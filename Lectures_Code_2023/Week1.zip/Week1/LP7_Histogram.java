
public class LP7_Histogram
{
   static String str = "Welcome to Java and Love Programming in Java"; 
   static int[] U = new int[26];
   static int[] L = new int[26];
    public static int count(String s, char c){
       int cc = 0;  // default return value if not found in search

       for (int i=0; i<s.length(); i++){
          if (s.charAt(i)==c) {
              cc++; 
            }
        }
       
       return cc; 
    }
    
    public static void main(String[] args){
       System.out.print("\f"); 
       for (int i= 'A'; i<'Z'+1; i++){
           U[i-'A'] = count(str, (char)i); 
           System.out.println(((char)i)+" shows up "+U[i-'A']+" times"); 
        }
       for (int i= 'a'; i<'z'+1; i++){
           L[i-'a'] = count(str, (char)i); 
           System.out.println(((char)i)+" shows up "+L[i-'a']+" times"); 
        }
     }
}
