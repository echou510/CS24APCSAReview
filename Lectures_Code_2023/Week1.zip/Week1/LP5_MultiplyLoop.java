
public class LP5_MultiplyLoop
{
   static int[][] a = new int[9][9]; 
   public static void main(String[] args){
    System.out.print("\f"); 
    for (int i=0; i<9; i++){
       for (int j=0; j<9; j++){
           a[i][j] = (i+1)+(j+1); 
           System.out.printf("%2d ", a[i][j]);           
        }
       System.out.println(); 
    }
   }
}
