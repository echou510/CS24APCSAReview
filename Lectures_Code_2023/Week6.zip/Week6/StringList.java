import java.lang.Iterable;
import java.util.Iterator;  
import java.util.NoSuchElementException;
import java.util.Arrays; 
public class StringList implements Iterable<String>, Iterator<String>{ 
   String[] list = new String[10]; 
   int length=0;
   int i = 0;
   StringList(String[] source){
       list = source; 
       length = list.length; 
    }
   public int size(){ return length; }
   public Iterator<String> iterator(){
       return this; 
    }
   public String toString(){
      return Arrays.toString(list);  
   }
   public boolean hasNext(){
       return i<length; 
   }
   public String next(){
        if (!hasNext()) throw new NoSuchElementException();
        return list[i++];
   }
   public void remove(){
     throw new UnsupportedOperationException();  
   }
   public void reset(){
       i=0; 
   } 
   public static void main(String[] args){
       String[] s = {"alpha", "beta", "gamma", "delta", "epsilon"};
       StringList alist = new StringList(s); 
       //System.out.println(alist); 
       //System.out.println(alist.size()); 
       for (String str: alist){
           System.out.println(str); 
        }
       for (String str: alist){
           System.out.println(str); 
        }
    }
}
