import java.util.ArrayList; 
public class CreateArray
{
  public static void main(String[] args){
   int count =5; 
   ArrayList<Integer> aList= new ArrayList<Integer>(); 
   for (int i=0; i<5; i++){
      aList.add((int)(Math.random()*8)); 
   }
   System.out.println("Loop Creation of an ArrayList: "+aList); 
  }
}
