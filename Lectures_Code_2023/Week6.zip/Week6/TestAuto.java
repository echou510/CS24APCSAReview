public class TestAuto {
    public static void main(String[] args) {
        //define an Auto reference
        //init it
        Auto auto = new Auto();
        //init object values
        auto.maxSpeed = 160;
        auto.noSeats = 5;
        auto.weight = 1500;
 
        //define and init an array reference
        int[] someInts = new int[3];
        someInts[0] = 10;
        someInts[1] = 20;
        someInts[2] = 30;
        
        //
        Auto newAuto = auto;
        int[] otherInts = someInts;
        
        newAuto.maxSpeed = 200; //same result as auto.maxSpeed = 200;
        System.out.println(auto.maxSpeed);  //prints 200
        otherInts[0] = 40;  //same result as someInts[0] = 40;
        System.out.println(someInts[0]);  //prints 40
    }
}