import java.util.*;
public class ParseInt
{
  public static void main(String[] args){
      System.out.print("\f");
      
      Scanner input = new Scanner(System.in); 
      System.out.print("Enter a Number:"); 
      String str = input.nextLine(); 
      while (!str.equals("999")){
           int x = Integer.parseInt(str, 2);
           System.out.println("My number is : "+x); 
           System.out.print("Enter a Number:"); 
           str = input.nextLine(); 
       }
    }
}
