
public abstract class EQ2 extends EQ
{
   public abstract int f(); 
}
