public class EQ
{
    static class A{
        int x;  // set to zero 
        
        public boolean equals(A other){
            return this.x == other.x; 
        }
        public String toString() {
           return ""+x;  // convert x to string type
        }
    }
    
    public static void main(String[] args){
      A a = new A(); 
      A b = new A(); 
      System.out.println(a); 
      System.out.println(b); 
      System.out.println((a==b));  // checking the hashCode() 
      System.out.println(a.equals(b)); 
    }
}
