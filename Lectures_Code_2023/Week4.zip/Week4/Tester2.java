import java.util.Scanner; 
import java.io.File; 
import java.util.Collections; 
import java.util.Iterator; 
public class Tester2
{
  public static void main(String[] args) throws Exception {
      System.out.print("\f");
      Scanner in = new Scanner(new File("points.csv"));
      LocationList list = new LocationList(); 
      while (in.hasNext()){
           String line = in.nextLine(); 
           String[] tokens = line.trim().split(","); 
           double x = Double.parseDouble(tokens[0]);
           double y = Double.parseDouble(tokens[1]); 
           Location z = new Location(x, y); 
           list.add(z); 
        }
        
      Collections.sort(list);
      Iterator j = list.iterator(); 
      int i=0; 
      System.out.print("["); 
      while (j.hasNext()){
          if      (i%3==0) { System.out.print(j.next());}
          else if (i%3==2) { System.out.print(", "+j.next()+",\n");}
          else             { System.out.print(", "+j.next());}    
          i++; 
        }
      System.out.println("]");
    }
}
