import java.util.Scanner; 
import java.io.File; 
import java.util.Collections; 

public class Tester
{
  public static void main(String[] args) throws Exception {
      System.out.print("\f");
      Scanner in = new Scanner(new File("points.csv"));
      LocationList list = new LocationList(); 
      while (in.hasNext()){
           String line = in.nextLine(); 
           String[] tokens = line.trim().split(","); 
           double x = Double.parseDouble(tokens[0]);
           double y = Double.parseDouble(tokens[1]); 
           Location z = new Location(x, y); 
           list.add(z); 
        }
        
      Collections.sort(list);
      System.out.println(list);
    }
}
