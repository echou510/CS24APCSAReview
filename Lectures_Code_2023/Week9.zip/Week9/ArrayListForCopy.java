import java.util.ArrayList; 
public class ArrayListForCopy
{
  public static void main(String[] args){
       ArrayList<Integer> original = new ArrayList<Integer>(); 
       original.add(23); 
       original.add(51); 
       original.add(14); 
       original.add(50); 
       ArrayList<Integer> duplicate = new ArrayList<Integer>(); 
       for (int i=0; i<original.size(); i++){
            duplicate.add(original.get(i)); 
        }
       System.out.print("\f"); 
       System.out.println("Original ="+original); 
       System.out.println("Duplicate="+duplicate); 
    }
}
