import java.util.Arrays; 
public class Difference
{
  public static int[] a={
       1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11
    }; 
  public static int[] b={
      1, 4, 3, 5, 6, 7, 0, 9
    };
  public static int[] c={0}; 
  public static boolean isStrictlyIncreasing(int[] x){
      for (int i=0; i< x.length-1; i++){
          if (x[i+1]<=x[i]) return false; 
        }
      return true; 
    }
  public static int maxSlope(int[] x){
      int max = Integer.MIN_VALUE; 
      if (x.length<2) return 0; 
      for (int i=0; i< x.length-1; i++){
          if (x[i+1]-x[i]> max) { max = x[i+1]-x[i]; }
        }
      return max; 
    }
  public static int minSlope(int[] x){
      int min = Integer.MAX_VALUE; 
      if (x.length<2) return 0; 
      for (int i=0; i< x.length-1; i++){
          if (x[i+1]-x[i]< min) { min = x[i+1]-x[i]; }
        }
      return min; 
    }
  public static int maxDelta(int[] x){
      int max = Integer.MIN_VALUE; 
      if (x.length<2) return 0; 
      for (int i=0; i< x.length-1; i++){
          if (Math.abs(x[i+1]-x[i])> max) { 
              max = (int) Math.abs(x[i+1]-x[i]); 
            }
        }
      return max; 
    }
  public static void main(String[] args){
      System.out.print("\f"); 
      System.out.println("A1 Part(a):"); 
      System.out.println(Arrays.toString(a)+
        " is strictly increasing = "+isStrictlyIncreasing(a)); 
      System.out.println(Arrays.toString(b)+
        " is strictly increasing = "+isStrictlyIncreasing(b)); 
      System.out.println(Arrays.toString(c)+
        " is strictly increasing = "+isStrictlyIncreasing(c)); 
      System.out.println("A1 Part(b):"); 
      System.out.println(Arrays.toString(a)+
        " maxSlope = "+maxSlope(a)); 
      System.out.println(Arrays.toString(b)+
        " maxSlope = "+maxSlope(b)); 
      System.out.println(Arrays.toString(c)+
        " maxSlope = "+maxSlope(c)); 
      System.out.println("A1 Part(c):"); 
      System.out.println(Arrays.toString(a)+
        " minSlope = "+minSlope(a)); 
      System.out.println(Arrays.toString(b)+
        " minSlope = "+minSlope(b)); 
      System.out.println(Arrays.toString(c)+
        " minSlope = "+minSlope(c)); 
      System.out.println("A1 Part(d):"); 
      System.out.println(Arrays.toString(a)+
        " maxDelta = "+maxDelta(a)); 
      System.out.println(Arrays.toString(b)+
        " maxDelta = "+maxDelta(b)); 
      System.out.println(Arrays.toString(c)+
        " maxDelta = "+maxDelta(c)); 
    }
}
