import java.util.Scanner; 
public class Go{
    public static String B = "B"; 
    public static String W = "W"; 
    public static String S = " "; 
    public static String[][] gameboard ={
      {S, S, S, S, W, B, W, S, S},  
      {S, B, S, S, B, W, S, S, S},  
      {S, S, S, S, W, S, S, S, S},  
      {S, B, B, S, S, S, S, S, S},  
      {S, B, W, B, S, S, S, S, S},  
      {W, W, B, S, S, S, S, W, S},  
      {W, B, S, S, S, S, W, B, W},  
      {B, W, S, S, S, S, B, W, B},  
      {W, S, S, S, S, S, S, B, W}
    };
    public static void display(String[][] m){
       System.out.println("  0 1 2 3 4 5 6 7 8");
       for (int i=0; i<m.length; i++){
            System.out.print(i+" ");
            for (int j=0; j<m[i].length; j++){
               System.out.print(m[i][j]+" ");
            }
            System.out.println(); 
        }
    }
    public static boolean isDead(String[][] board, int r, int c){
       boolean top=false, left=false, bottom=false, right=false; 
       String stoneColor = board[r][c];
       boolean isSpace = board[r][c].equals(S); 
       if (r==0) top = true;               
       else      top = !isSpace && !board[r-1][c].equals(S) && !stoneColor.equals(board[r-1][c]); 
       if (c==0) left = true;              
       else      left = !isSpace && !board[r][c-1].equals(S) && !stoneColor.equals(board[r][c-1]); 
       if (r==board.length-1) bottom = true; 
       else                   bottom = !isSpace && !board[r+1][c].equals(S) && !stoneColor.equals(board[r+1][c]); 
       if (c==board.length-1) right  = true; 
       else                   right  = !isSpace && !board[r][c+1].equals(S) && !stoneColor.equals(board[r][c+1]);   
       return top && bottom && left && right; 
    }
    public static void main(String[] args){
       Scanner in = new Scanner(System.in); 
       System.out.print("\f");
       boolean done = false; 
       System.out.print("\f");
       display(gameboard);
       System.out.println(); 
       while (!done){
           System.out.print("Enter row number (999 to exit):");
           int r=in.nextInt();
           int c; 
           if (r==999) done = true;
           if (!done){
               System.out.print("Enter column number:");
               c = in.nextInt(); 
               boolean b = isDead(gameboard, r, c);
               System.out.println("Stone["+r+","+c+"]="+b); 
            }
        }
    }
}
