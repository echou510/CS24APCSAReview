public class Occurrence{
                           //0         1         2         3         4         5         6         7
                           //01234567890123456789012345678901234567890123456789012345678901234567890123456789
    public static String a= "Ha Ha Ha Ha! HaHaHa! I am a happy person, HaHaHa! I have a million dollar."; 
    public static int find(String str, String pattern){
      if (str.indexOf(pattern) >=0) return str.indexOf(pattern); 
      return -1; 
    }
     public static int findN(String str, String pattern, int n){
      int i=-1;
      int pos =0; 
      int count = 0;
      while (str.indexOf(pattern, pos) >=0 && count != n) {
          i = str.indexOf(pattern, pos); 
          pos = i+1; 
          count++; 
        }
      if (count != n) return -1; 
      return i; 
    }
    public static int findL(String str, String pattern){
        int i = -1; 
        int pos =0; 
        while (str.indexOf(pattern, pos) >=0) {
            i = str.indexOf(pattern, pos); 
            pos = i+1; 
        }
        return i; 
    }
     public static int findAN(String str, String pattern, int n){
      int i=-1;
      int pos =0; 
      int count = 0;
      while (str.indexOf(pattern, pos) >=0 && count != n) {
          i = str.indexOf(pattern, pos); 
          pos = i+pattern.length(); 
          count++; 
        }
      if (count != n) return -1; 
      return i; 
    }
    public static int findAL(String str, String pattern){
        int i = -1; 
        int pos =0; 
        while (str.indexOf(pattern, pos) >=0) {
            i = str.indexOf(pattern, pos); 
            pos = i+pattern.length(); 
        }
        return i; 
    }
    public static void main(){
       System.out.print("\f"); 
       System.out.println("A2 Part(a):"); 
       System.out.println("0         1         2         3         4         5         6         7"); 
       System.out.println("01234567890123456789012345678901234567890123456789012345678901234567890123456789"); 
       System.out.println(a); 
       System.out.println(find(a.toLowerCase(), "ha")); 
       System.out.println(findN(a.toLowerCase(), "ha", 6));  // Overlapping
       System.out.println(findL(a.toLowerCase(), "ha")); 
       System.out.println(findAN(a.toLowerCase(), "ha", 6)); // Non-Overlapping
       System.out.println(findAL(a.toLowerCase(), "ha")); 
       System.out.println("A2 Part(b):"); 
       String b = "bbb bbb bbbbb";
       System.out.println(b); 
       System.out.println(find(b.toLowerCase(), "bb")); 
       System.out.println(findN(b.toLowerCase(), "bb", 3));  // Overlapping
       System.out.println(findL(b.toLowerCase(), "bb")); 
       System.out.println(findAN(b.toLowerCase(), "bb", 3)); // Non-Overlapping
       System.out.println(findAL(b.toLowerCase(), "bb")); 
       
    }
}
