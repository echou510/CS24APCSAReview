public class FindMaxIndex{
  static int[] ary = {3, 5, 8, 12, 4, 0, 1, -4, 9, 17}; 
  
  public static int findMaxIndex1(int[] ary){
      int max = Integer.MIN_VALUE; 
      int maxIndex = -1; 
      for (int i=0; i<ary.length; i++){
          if (ary[i] >= max) { max = ary[i]; maxIndex = i; }
        }
      return maxIndex; 
    }
    
  public static int findMaxIndex2(int[] ary){
      int max;  int maxIndex = 0; 
      if (ary.length>0) max = ary[0];  else return Integer.MIN_VALUE; 
      for (int i=1; i<ary.length; i++){
          if (ary[i] >= max) { max = ary[i];  maxIndex = i; }
        }
      return maxIndex; 
    }
    
  public static void main(String[] args){
      System.out.println(findMaxIndex1(ary)); 
      System.out.println(findMaxIndex2(ary)); 
    }
}


