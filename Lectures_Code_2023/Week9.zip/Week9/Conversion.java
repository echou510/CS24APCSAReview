public class Conversion{
   static String global_population = "7,599,908,150";  // as of 02/05/2018
    
   public static void main(String[] args){
      String[] sections = global_population.split(",");
      String integer = ""; 
      for (int i=0; i<sections.length; i++){
           sections[i] = sections[i].trim(); 
           integer += sections[i];       // integer is the accumulator
        }
      Long number = Long.parseLong(integer);
      System.out.println("Global Population as of 02/05/2018 is "+number); 
    }
}
