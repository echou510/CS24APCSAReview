public class PassByReference
{
    public static void goAhead(Circle c, int n){
       c.setRadius(50); 
       n=50; 
    }
    
    public static void main(String[] args){
       Circle myCircle = new Circle(100); 
       int number = 100; 
       goAhead(myCircle, number); 
       System.out.println(myCircle.getRadius()); 
       System.out.println(number); 
    }
}

