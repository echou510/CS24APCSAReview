public class Methods3{
    public static <T> void doSomething(T param){
        System.out.println("T: "+param); 
    }
    public static <T, E> void doSomething(T a, E b){
        System.out.println("T: "+a+"  E: "+b); 
    }

    public static void main(String[] args){
       Integer a=3; Double b=5.0; 
       doSomething(a); 
       doSomething(b); 
       doSomething(a, b); 
       doSomething(b, a); 
    }
}
