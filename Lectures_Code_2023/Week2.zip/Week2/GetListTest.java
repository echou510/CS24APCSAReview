import java.util.*; 
public class GetListTest { 
    /** Returns a list of integers from the keyboard. */
    public static ArrayList<Integer> getList() { 
        Scanner input = new Scanner(System.in); 
        ArrayList<Integer> a = new ArrayList<Integer>(); 
        System.out.println("Enter an Integer(bye to quit): "); 
        String st = input.nextLine(); 
        while (!st.toLowerCase().equals("bye")){
            int x = Integer.parseInt(st); 
            a.add(x); 
            System.out.println("Enter an Integer(bye to quit): "); 
            st = input.nextLine(); 
        }
        return a; 
    } 
    /** Write contents of ArrayList a. */ 
    public static void writeList(ArrayList<Integer> a) { 
        System.out.println("List is : " + a); 
    } 
    public static void main(String[] args) { 
        ArrayList<Integer> list = getList(); 
        writeList(list) ; 
    } 
} 
