
public class CountAB
{
    static String a = "abccabkdjskrfsabbadskajbabbbababaab"; 
    
    public static int countAB(String a){
       int c =0; 
       for (int i=0; i<a.length()-1; i++){
           if (a.substring(i, i+2).equals("ab")) c++; 
        }
       return c; 
    }
    
    public static void main(String[] args){
      System.out.printf("CountAB(a)=%d\n", countAB(a)); 
    }
}
