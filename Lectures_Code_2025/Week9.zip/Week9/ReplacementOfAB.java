
public class ReplacementOfAB
{
    static String s = "ab__ab_abb__aabb__ab";
    
    public static String replace(String s, String pat, String re){
        String r = ""; 
        for (int i=0; i<s.length(); ){
          if (i<s.length()-pat.length()+1 && s.substring(i, i+pat.length()).equals(pat)){
               r += re; 
               i += pat.length(); 
            }
          else{
               r += s.charAt(i); 
               i++; 
            }
        }
        return r; 
    }
    
    public static void main(String[] args){
      System.out.printf("String : %s\nReplace: %s\n", s, replace(s, "ab", "cdf"));
    }
}
