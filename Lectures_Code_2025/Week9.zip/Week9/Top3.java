import java.util.*; 
public class Top3
{
    static int[] a = {9, 2, 1, 8, 7, 6, 4, 5, 3}; 
    static ArrayList<Integer> t = new ArrayList<Integer>(
       Arrays.asList(new Integer[]{0, 0, 0}) 
    );
    
    public static void keepTop3(ArrayList<Integer> t, int[] a){
      for (int x: a){
           int d =0; 
           while (d<t.size() && t.get(d)>=x) d++; 
           t.add(d, x); 
           t.remove(t.size()-1); 
        }
    }
    
    public static void main(String[] args){
       keepTop3(t, a); 
       System.out.printf("Top 3(a) = %s\n", t); 
    }
}
