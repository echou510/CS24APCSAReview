
public class StrictlyIncreasing
{
   static int[] a={1, 3, 4, 5, 6, 6, 7, 8, 9}; 
   
   public static boolean isStrictlyIncreasing(int[] a){
      for (int i=0; i<a.length-1; i++){
          if (a[i+1]<=a[i]) return false; 
        }
      return true; 
    }
    
   public static boolean isIncreasing(int[] a){
      for (int i=0; i<a.length-1; i++){
           if (a[i+1]<a[i]) return false; 
        }
      return true;  
    }
    
   public static void main(String[] args){
      System.out.printf("a[] is strictly increasing is %b\n", isStrictlyIncreasing(a));
      System.out.printf("a[] is increasing si %b\n", isIncreasing(a));
    }
}
