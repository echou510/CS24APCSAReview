
public class RandomInput
{
    public static void main(String[] args){
       int c = 0; 
       
       int dice = (int)(Math.random()*6)+1;
       while (dice != 6){
           c++; 
           dice = (int)(Math.random()*6)+1;
        }
       // exit condition: dice == 6
       System.out.printf("%d toss before a 6\n", c); 
    }
}
