
public class ABC
{
    static String s = "abcdefghijklmnopqr"; 
    
    public static String oneTwo(String s){
       String r=""; 
       for (int i=0; i<s.length()/3*3; i+= 3){
           String three = s.substring(i+1, i+3)+s.charAt(i); 
           r += three; 
        }
       return r; 
    }
    
    public static void main(String[] args){
      System.out.println(oneTwo(s)); 
    }
}
