
public class Toggler
{
    int x; 
    
    Toggler(int n){ x=n; }
    public void toggle(){ x = 1-x; }
    public String toString() { return ""+x; }
    
    public static void main(String[] args){
      Toggler t = new Toggler(1);
      for (int i=0; i<10; i++){
          System.out.println(t);
          t.toggle(); 
        }
    }
}
