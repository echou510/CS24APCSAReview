
public class AllEven
{
    public static int[] a= {2, 4, 6, 8, 10}; 
    
    public static boolean allEven(int[] a){
      for (int i=0;i<a.length;i++){
          if(a[i]%2==1) return false; 
        }
      return true;
    }
    
    public static boolean hasEven(int[] a){
       for (int i=0; i<a.length; i++){
          if (a[i]%2==0) return true; 
        }
       return false; 
    }   
    
    public static void main(String[] args){
      System.out.printf("a[] is all even is %b\n", allEven(a));
      System.out.printf("a[] has even is %b\n", hasEven(a));
    }
}
