
public class SuccessiveDivision
{
    static int a = 12345; 
    
    public static int sumOfDigits(int n){
      int s = 0; 
      while (n>0){
          int d = n%10; 
          s += d; 
          n /=10;
        }
      return s; 
    }
    
    public static int reverse(int n){
       int r = 0; 
       while (n>0){
          r = r*10 + n%10; 
          n /=10; 
        }
       return r; 
    }
    
    public static String toBinary(int n){
       String b =""; 
       while (n>0){
          int d = n %2; 
          b = d + b;
          n /=2; 
        }
       return b; 
    }
    
    public static void main(String[] args){
      System.out.printf("Sum of Digits(a)=%d\n", sumOfDigits(a));
      System.out.printf("Reverse(a)=%d\n", reverse(a));
      System.out.printf("Binary(a)=%s\n", toBinary(a));
    }
}
