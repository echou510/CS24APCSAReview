
public class TriStateToggler
{
    int x = 0; 
    
    TriStateToggler(){ x= 0; }
    public void toggle(){ x += 1; x %=3; }
    public String toString(){ return ""+x; }
    
    public static void main(String[] args){
      TriStateToggler t = new TriStateToggler();
      for (int i=0; i<10; i++){
          System.out.println(t);
          t.toggle(); 
        }
    }
}
