public class ToBinary
{
   public static String toBinary(int dec){
       String r = ""; 
       while (dec >0){
           int bit = dec % 2; 
           r = ""+bit+r;
           dec /=2; 
        }
       return r; 
    }
   public static void main(String[] args){
       System.out.print("\f");
       System.out.println(toBinary(127)); 
       System.out.println(toBinary('A'));
       System.out.println(toBinary('z'));
    }
}

