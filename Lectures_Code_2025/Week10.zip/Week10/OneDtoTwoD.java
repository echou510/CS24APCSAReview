import java.util.*; 
public class OneDtoTwoD
{
    static int[] a ={1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; 
    
    static int[][] m = new int[3][4]; 
    static int[][] n = new int[2][3]; 
    
    public static void printMatrix(int[][] m){
       for (int i=0; i<m.length; i++){
           for (int j=0; j<m[0].length; j++){
               System.out.printf("%3d", m[i][j]);
            }
           System.out.println(); 
        }
    }
    
    public static void fillMatrix(int[][] m, int[] a){
        int p=0; 
        for (int i=0; i<m.length; i++){
           for (int j=0; j<m[0].length; j++){
               if (p<a.length) m[i][j] = a[p++];
            }
        }
    }
    
    public static void main(String[] args){
       fillMatrix(m, a); 
       printMatrix(m); 
       System.out.println(); 
       
       fillMatrix(n, a); 
       printMatrix(n); 
    }
}
