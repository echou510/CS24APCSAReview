
public class Location
{
    int x; 
    int y; 
    Location(int x, int y){ this.x = x; this.y =y; }
    
    public int getRow(){ return x;}
    public int getColumn(){ return y;}
    public Location next(){ return new Location((int)(Math.random()*3), (int)(Math.random()*4)); }
    
    public String toString(){
       return "<"+x+", "+y+">";
    }
}

