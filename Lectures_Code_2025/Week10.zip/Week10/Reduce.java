
public class Reduce
{
     static int[][] m = {
      {1, 2, 3, 4}, 
      {5, 6, 7, 8}, 
      {9, 10, 11, 12}, 
      {13, 14, 15, 16}
    }; 

    public static int[][] reduce(int[][] m, int row){
      if (row <0 || row >=m.length) return m; // no change
      
      int[][] n = new int[m.length-1][m[0].length]; 
      
      for (int r=0; r<row; r++){
           for (int c=0; c<m[0].length; c++){
              n[r][c] = m[r][c]; 
            }
        }
      
      for (int r=row; r<m.length-1; r++){
          for (int c=0; c<m[0].length; c++){
              n[r][c] = m[r+1][c]; 
            }
        }
      return n; 
    }
    
    public static void printMatrix(int[][] m){
       for (int i=0; i<m.length; i++){
           for (int j=0; j<m[i].length; j++){
               System.out.printf("%3d", m[i][j]); 
            }
           System.out.println(); 
        }
    }
    public static void main(String[] args){
       int[][] n = reduce(m, 1); 
       printMatrix(n); 
    }
}
