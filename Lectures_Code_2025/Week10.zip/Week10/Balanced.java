
public class Balanced
{
    static String[] patterns = {
     ")()", "()()", "())", "()(()())"
    }; 
    public static boolean balanced(String s){
       int level = 0; 
       for (int i=0; i<s.length(); i++){
           if (s.charAt(i)=='(') level++; 
           if (s.charAt(i)==')') level--; 
           if (level<0) return false; 
        }
       
       return level ==0; 
    }
    
    public static void main(String[] args){
       for (int i=0; i<patterns.length; i++){
           System.out.printf("Pattern %s is balanced is %b\n", 
           patterns[i], balanced(patterns[i])); 
        }
    }
}
