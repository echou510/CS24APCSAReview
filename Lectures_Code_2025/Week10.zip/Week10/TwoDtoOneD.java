import java.util.*; 
public class TwoDtoOneD
{
    static int[][] m = {
     {1, 2, 3, 4}, 
     {5, 6, 7, 8}, 
     {9,10, 11, 12}
    };
    
    public static int[] TwoToOne(int[][] m){
       int p = 0; 
       int[] a = new int[m.length*m[0].length]; 
       
       for (int r=0; r<m.length; r++){
           for (int c=0; c<m[0].length; c++){
               a[p++] = m[r][c];
            }
        }
       return a; 
    }
    public static int[] TwoToOne2(int[][] m){
       int p = 0; 
       int[] a = new int[m.length*m[0].length]; 
       
       for (int r=0; r<m.length; r++){
           for (int c=0; c<m[0].length; c++){
               a[r*m[0].length+c] = m[r][c];
            }
        }
       return a; 
    }
    public static void main(String[] args){
       System.out.println(Arrays.toString(TwoToOne(m))); 
       System.out.println(Arrays.toString(TwoToOne2(m))); 
    }
}
