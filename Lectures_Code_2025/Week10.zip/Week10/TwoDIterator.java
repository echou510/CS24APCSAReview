
public class TwoDIterator
{
    int M; // number of rows
    int N; // number of columns
    int itr =0; 
    
    TwoDIterator(int m, int n){ M=m; N=n;  itr=0; }
    
    public void reset(){ itr=0; }
    
    public boolean hasNext(){ return itr >=0 && itr < M*N; }
    
    public int getRow(){ return itr/N; }
    public int getColumn(){ return itr%N; }
    
    public int next(){ 
        int x = itr; 
        itr++; 
        if (x >= M*N) return -1; 
        return x; 
    }
}
