
public class Mirror
{
   static int[][] m = {
      {1, 2, 3, 4}, 
      {5, 6, 7, 8}, 
      {9, 10, 11, 12}, 
      {13, 14, 15, 16}
    }; 
    
   public static void printMatrix(int[][] m){
       for (int i=0; i<m.length; i++){
           for (int j=0; j<m[i].length; j++){
               System.out.printf("%3d", m[i][j]); 
            }
           System.out.println(); 
        }
    }
    
   public static void mirrorHorizontal(int[][] m){
       for (int i=0; i<m.length; i++){
           for (int j=0; j<m[i].length/2; j++){
               int tmp = m[i][j]; 
               m[i][j] = m[i][m[i].length-1-j]; 
               m[i][m[i].length-1-j] = tmp; 
            }
        }
    }
    
   public static void mirrorVertical(int[][] m){
       for (int i=0; i<m.length/2; i++){
           for (int j=0; j<m[i].length; j++){
               int tmp = m[i][j]; 
               m[i][j] = m[m.length-1-i][j]; 
               m[m.length-1-i][j] = tmp; 
            }
        }
    }
   public static void main(String[] args){
      printMatrix(m); 
      System.out.println(); 
      mirrorHorizontal(m); 
      printMatrix(m); 
      
      System.out.println(); 
      mirrorVertical(m); 
      printMatrix(m); 
    }
}
