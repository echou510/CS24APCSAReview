
/**
 * Write a description of class Delimiters here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Delimiters
{
    static int[] a = {1, 2, 3, 4, 5}; 
    
    public static String addDelimiters(int[] a, String del){
       String s = ""; 
       for (int i=0; i< a.length; i++){
           if (i==0) s += a[i]; 
           else s += del+a[i]; 
        }
       return s; 
    }
    
    public static String addDelimiters2(int[] a, String del){
       String s = ""; 
       for (int i=0; i< a.length; i++){
           if (i==a.length-1) s += a[i]; 
           else s += a[i]+del; 
        }
       return s; 
    }
    
    public static void main(String[] args){
       System.out.println(addDelimiters(a, "+"));
       System.out.println(addDelimiters2(a, "-"));
    }
}
