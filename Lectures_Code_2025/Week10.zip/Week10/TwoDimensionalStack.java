import java.util.*;
public class TwoDimensionalStack
{
   static int[][] m = {
      {1, 2, 3, 4}, 
      {5, 6, 7, 8}, 
      {9, 10, 11, 12}
    }; 
    
   public static void main(String[] args){
       Location a = new Location(3, 4);
       
       ArrayList<Location> alist = new ArrayList<Location>(); 
       
       for (int i=0; i<10; i++){
           alist.add(a.next());
        }
       System.out.println("Forward: ");
       for (Location x: alist){
            int row = x.getRow(); 
            int column = x.getColumn(); 
            System.out.printf("m[%d][%d] = %d\n", row, column, m[row][column]);
        }
       System.out.println(); 
       System.out.println("Backup: "); 
       while (alist.size()>0){
           Location x = alist.remove(alist.size()-1);
            int row = x.getRow(); 
            int column = x.getColumn(); 
            System.out.printf("m[%d][%d] = %d\n", row, column, m[row][column]);
        }
    }
}

