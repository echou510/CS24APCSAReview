
public class TwoDimensionalZigZag
{
   static int[][] m = {
      {1, 2, 3, 4}, 
      {5, 6, 7, 8}, 
      {9, 10, 11, 12}, 
      {13, 14, 15, 16}
    }; 
    
   public static void traversal(int[][] m){
       for (int i=0; i<m.length; i++){
          if (i%2==0){
               for (int j=0; j<m[i].length; j++){
                   System.out.printf("%3d", m[i][j]);
                }
               System.out.println(); 
            }
          else{
            for (int j=m[i].length-1; j>=0; j--){
                   System.out.printf("%3d", m[i][j]);
                }
               System.out.println(); 
            }
        }  
    }
    
   public static void columnMajor(int[][] m){
       for (int c=0; c<m[0].length; c++){
           for (int r=0; r<m.length; r++){
               System.out.printf("%3d", m[r][c]);
            }
           System.out.println();
        }
    }
   public static void main(String[] args){
       traversal(m); 
       System.out.println(); 
       columnMajor(m);
    }
}
