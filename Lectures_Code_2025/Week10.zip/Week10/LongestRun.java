import java.util.*; 
public class LongestRun
{
    static int[] a ={
     1, 1, 1, 2, 2, 2, 2, 3, 3, 4, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 7, 7, 7, 7, 8, 8, 9, 9, 9, 9,9, 9
    }; 
    
    public static int run(int[] a){
      int m=0; 
      int r=1; 
      for (int i=1; i<=a.length; i++){
           if (i==a.length || a[i]!=a[i-1]){
               if (r>m) m = r; 
               r=1; 
            }
           else r++; 
        }
      return m; 
    }
    public static int run2(int[] a){
      ArrayList<Integer> cuts = new ArrayList<Integer>(); 
      cuts.add(0); 
      for (int i=1; i<a.length; i++){
          if (a[i-1] != a[i]) cuts.add(i); 
        }
      cuts.add(a.length);
      
      int m=0; 
      for (int i=0;i<cuts.size()-1; i++){
          int step = cuts.get(i+1)-cuts.get(i); 
          if (step>m) m = step; 
        }
      return m; 
    }
    public static void main(String[] args){
       System.out.println(run(a)); // 5
       System.out.println(run2(a)); // 5
    }
}
