
public class UseIndexOf
{
    static String s = "aasbabdfsaabbababewriuwbaavbabba"; 
    static String t = "xbbxxxxbbxxxx"; 
    
    public static int countAB(String s, String pat){
        int c= 0; 
        int pos = s.indexOf(pat); 
        while (pos >=0){
            c++; 
            pos = s.indexOf(pat, pos+1); 
        }
        return c; 
    }
    public static int countABNonOverlapping(String s, String pat){
        int c= 0; 
        int pos = s.indexOf(pat); 
        while (pos >=0){
            c++; 
            pos = s.indexOf(pat, pos+pat.length()); 
        }
        return c; 
    }
    public static void main(String[] args){
       System.out.printf("How many ab in s? %d\n", countAB(s, "ab")); 
       System.out.printf("How many xx in t (overlapping)? %d\n", countAB(t, "xx")); 
       System.out.printf("How many xx in t (nonoverlapping)? %d\n", countABNonOverlapping(t, "xx")); 
    }
}
