public class Sum67
{
    static int[] a = { 1, 2, 6, 3, 4, 7, 5, 6, 7, 8, 9}; 
    
    public static int sum67(int[] a){
      int s = 0;
      boolean skip = false; 
      
      for (int i=0; i<a.length; i++){
           if (a[i]==6) skip = true; 
           if (!skip) s += a[i]; 
           if (a[i]==7) skip = false; 
        }
      
      return s; 
    }
    
    public static void main(String[] args){
       System.out.println(sum67(a)); // 1+2+5+8+9 
    }
}
