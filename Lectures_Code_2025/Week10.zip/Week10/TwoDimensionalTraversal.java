public class TwoDimensionalTraversal
{
   static int[][] m = {
      {1, 2, 3, 4}, 
      {5, 6, 7, 8}, 
      {9, 10, 11, 12}
    }; 
    
   public static void traversal(int[][] m){
       TwoDIterator td = new TwoDIterator(m.length, m[0].length); 
       td.reset(); 
       
       while(td.hasNext()){
           System.out.println(m[td.getRow()][td.getColumn()]); 
           td.next(); 
        }
    }
    
   public static void main(String[] args){
       traversal(m); 
    }
}
