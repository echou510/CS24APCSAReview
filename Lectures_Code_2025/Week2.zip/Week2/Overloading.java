
public class Overloading
{
   public int product(int n) { return n * n; } 
   public double product(double x) { return x * x; } 
   public double product(int x, int y) { return x * y; } 
}
