public class Circle1{
  double radius = 10.0;   
  Circle1(double r){  // constructor 
      radius = r; 
    }
  public double getArea(){
      return Math.PI * radius * radius; 
    }  
  public double getPerimeter(){
      return 2*Math.PI*radius; 
    }
  public double getRadius(){ return radius; } 
  public void   setRadius(double r){ radius = r; }
  public String toString(){ return "Cirle[r="+radius+"]";}
  public static void main(String[] args){
      Circle1 circle = new Circle1(5.0); 
      System.out.println(circle); 
    }
}
