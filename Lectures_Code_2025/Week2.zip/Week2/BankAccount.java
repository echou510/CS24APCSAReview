import java.util.*; 
public class BankAccount
{
     final static double OVERDRAWN_PENALTY = 100.0; 
     private static double intRate; 

     String password; 
     double balance; 
     BankAccount(){
          password = ""; 
          balance = 0.0; 
        }
        
     /** Constructor. Constructs a bank account with
      * specified password and balance. 
      */
     public BankAccount(String acctPassword, double acctBalance) { 
        password = acctPassword; 
        balance = acctBalance; 
       } 
       
     /** Returns the balance of this account. */ 
     public double getBalance() { return balance; } 
  
     /** Deposits amount in a bank account with the given password. */ 
     public void deposit(String acctPassword, double amount) throws Exception { 
         if (!acctPassword.equals(password))  
             /* throw an exception */ 
             throw new Exception(); 
         else 
             balance += amount; 
     } 
    
    /** Withdraws amount from bank account with given password. 
    * Assesses penalty if balance is less than amount. 
    */ 
    public void withdraw(String acctPassword, double amount) throws Exception { 
    if (!acctPassword.equals(password)) 
    	/* throw an exception */ 
    	throw new Exception(); 
    else { 
        balance -= amount; 
        //allows negative balance 
        if (balance < 0) 
            balance -= OVERDRAWN_PENALTY; 
        } 
    } 
    
    // The static method getInterestRate may be as follows: 
    public static double getlnterestRate() { 
            Scanner input = new Scanner (System.in); 
            System.out.println("Enter interest rate for bank account"); 
            System.out.println("Enter in decimal form: "); 
            double intRate = input.nextDouble(); 
            return intRate; 
    } 
}
