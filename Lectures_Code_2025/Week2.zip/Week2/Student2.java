public class Student2{
   private String firstName; 
   private String lastName; 
   private int age; 
   public Student2(){}
   public Student2(String first){
       this(first, null, 0); 
    }
   public Student2(String first, String last){
       this(first, last, 0); 
    }
   public Student2(String first, String last, int yearsold){
       firstName = first; 
       lastName  = last; 
       age       = yearsold; 
    }
}


