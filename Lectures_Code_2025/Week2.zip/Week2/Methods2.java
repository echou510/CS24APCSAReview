public class Methods2{
    public static void doSomething(Object param){
        System.out.println("Object: "+param); 
    }
    public static void doSomething(Object a, Object b){
        System.out.println("Object: "+a+"  Object: "+b); 
    }

    public static void main(String[] args){
       Integer a=3; Double b=5.0; 
       doSomething(a); 
       doSomething(b); 
       doSomething(a, b); 
       doSomething(b, a); 
    }
}
