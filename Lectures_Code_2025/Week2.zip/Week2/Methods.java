public class Methods{
    public static void doSomething(int param){
        System.out.println("INT: "+param); 
    }
    public static void doSomething(double param){
        System.out.println("DOUBLE: "+param); 
    }
    public static void doSomething(int a, double b){
        System.out.println("INT: "+a+"  Double: "+b); 
    }
    public static void doSomething(double a, int b){
        System.out.println("DOUBLE: "+a+"  INT: "+a); 
    }
    public static void main(String[] args){
       int a=3; double b=5; 
       doSomething(a); 
       doSomething(b); 
       doSomething(a, b); 
       doSomething(b, a); 
    }
}
