import java.util.List; 
import java.util.ArrayList; 
public class DynamicFamilyPerson{
  public static void main(String[] args){
      FamilyPerson mom = new FamilyPerson(); 
      FamilyPerson junior = new Baby(); 
      FamilyPerson auntSue = new SporkUser(); 
      List<FamilyPerson> family = new ArrayList<FamilyPerson>(); 
      family.add(mom); 
      family.add(junior); 
      family.add(auntSue); 
      for (FamilyPerson member: family){
          System.out.println(member.drink()); 
          System.out.println(member.eat()); 
          System.out.println(); 
        }
    }
}
