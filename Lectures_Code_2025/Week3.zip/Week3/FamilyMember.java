public class FamilyMember{
  public void eat(){
       System.out.println("Class: "+getClass().getName()); 
    }
  public static void timeToEat(Object hungryMember){
      ((FamilyMember) hungryMember).eat(); 
    }
  public static void main(String[] args){
     FamilyMember uncleDon = new FamilyMember();
     timeToEat(uncleDon); 
    }
}

