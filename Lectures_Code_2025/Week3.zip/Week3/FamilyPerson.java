public class FamilyPerson{
   public String drink(){ return "cup"; }
   public String eat()  { return "fork";}
   public static void main(String[] args){
     FamilyPerson mom = new FamilyPerson(); 
     Baby junior = new Baby(); 
     SporkUser auntSue = new SporkUser(); 
     System.out.print("\f"); 
     System.out.println(mom.drink()); 
     System.out.println(junior.drink()); 
     System.out.println(auntSue.drink()); 
     System.out.println(mom.eat()); 
     System.out.println(junior.eat()); 
     System.out.println(auntSue.eat());           
   }
}
