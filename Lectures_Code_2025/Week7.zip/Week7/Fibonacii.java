
/**
 * Write a description of class Fibonacii here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Fibonacii
{
    public static int fibo(int n){ 
       if (n<2) return 1;
       return fibo(n-2) + fibo(n-1); 
    }
    
    public static int fibodp(int n){
      if (n<2) return 1; 
      int f=0; 
      int f1=1; 
      int f2=1; 
      int i=2; 
      while (i<=n){
          f=f1 + f2;
          f2 = f1; 
          f1 = f; 
          i++; 
        }
      return f; 
    }
}
