
public class Accumulator
{
    static int[] a= {1, 2, 3, 4,5}; 
    
    public static int sum(int[] a){
       return sum(a, 0, 0); 
    }
    
    public static int sum(int[] a, int idx, int s){
      if (idx >=a.length) return s; 
      return sum(a, idx+1, s+a[idx]); 
    }
    
    public static void main(String[] args){
       System.out.println(sum(a)); 
    }
}
