//Java program to traverse the matrix using recursion
import java.util.Arrays;

class GfG {
    // Recursive function to traverse the matrix
    static void traverse(int[][] mat, int i, int j) {    
        // If the current position is the bottom-right 
        // corner of the matrix
        if (i == mat.length - 1 && j == mat[0].length - 1) {
            System.out.println(mat[i][j]);
            return;
        }
        // Print the value at the current position
        System.out.print(mat[i][j] + " ");
        // If the end of the current row has not
          // been reached
        if (j < mat[0].length - 1) {
          
            // Move right
            traverse(mat, i, j + 1);
        }
        // If the end of the current column has been reached
        else if (i < mat.length - 1) { 
            // Move down to the next row
            traverse(mat, i + 1, 0);
        }
    }

    public static void main(String[] args) {
        int[][] mat = { {1, 2, 3}, {4, 5, 6}, {7, 8, 9} };
        traverse(mat, 0, 0);
    }
}