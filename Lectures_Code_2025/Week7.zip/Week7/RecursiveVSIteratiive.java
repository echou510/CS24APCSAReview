public class RecursiveVSIteratiive
{
   static int fibonacciI(int n){
    int[] a = new int[n+1]; 
    a[0] = 1; 
    a[1] = 1; 
    for (int i = 2; i<=n; i++){
       a[i] = a[i-1] + a[i-2]; 
     }
    return a[n]; 
   } // runs faster
   static int fibonacciR(int n){
   if (n == 0 || n == 1) return 1; 
   return fibonacciR(n-1) + fibonacciR(n-2); 
   } // shorter code

   public static void main(String[] args){
     
     for (int i= 1; i<=40; i+= 1) {
     long time0 = System.currentTimeMillis(); 
       fibonacciI(i); 
     long time1 = System.currentTimeMillis(); 
       fibonacciR(i); 
     long time2 = System.currentTimeMillis(); 
     System.out.println("n="+i+"  Iterative Time: "+(time1-time0) +"  "+ "Recursive Time: "+(time2-time1)+"   Difference: "+(time2+time0 - time1-time1) ); 
    }
   }
}
