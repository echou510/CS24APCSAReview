public class Swap{
   public static void main(String[] args){
       System.out.println("\fBefore Rotational Swap: "); 
       int a = 3; 
       int b = 4; 
       System.out.println("A="+a+" B="+b); 
       int temp = a; 
       a = b; 
       b = temp; 
       System.out.println("After Rotational Swap:"); 
       System.out.println("A="+a+" B="+b); 
       
       System.out.println("\nBefore Shuffle Swap: "); 
       a = 3; 
       b = 4; 
       System.out.println("A="+a+" B="+b); 
       int ta = a; 
       int tb = b; 
       a = tb; 
       b = ta; 
       System.out.println("After Shuffle Swap:"); 
       System.out.println("A="+a+" B="+b);     
       
       System.out.println("\nBefore Swap Agent Swap: "); 
       a = 3; 
       b = 4; 
       System.out.println("A="+a+" B="+b); 
       Pack<Integer> p = new Pack<Integer>(a, b); 
       p=p.swap(); 
       a = p.x; 
       b = p.y; 
       System.out.println("After Shuffle Swap:"); 
       System.out.println("A="+a+" B="+b);    
    }
}

class Pack<T>{
  T x; 
  T y; 
  Pack(T a, T b){
       x = a; 
       y = b; 
    }
  
  Pack swap(){
      return new Pack(y, x); 
    }
}