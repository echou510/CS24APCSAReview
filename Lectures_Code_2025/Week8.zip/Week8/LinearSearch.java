public class LinearSearch {
  /** The method for finding a key in the list */
  public static int linearSearch(int[] list, int key) {
    for (int i = 0; i < list.length; i++) {
      if (key == list[i])
        return i;
    }
    return -1;
  }
  
  public static void main(String[] args){
       int[] list = {-2, 4, 5, 1, 2, -3, 9, -4, 8, 6, 7, 0};
       System.out.println("Key="+5+" Search Results is index="+linearSearch(list, 5));
       System.out.println("Key="+3+" Search Results is index="+linearSearch(list, -3));
       System.out.println("Key="+(-6)+" Search Results is index="+linearSearch(list, 6));
       System.out.println("Key="+11+" Search Results is index="+linearSearch(list, 11));
    }
}
