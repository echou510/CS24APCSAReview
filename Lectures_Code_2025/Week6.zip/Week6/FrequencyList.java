import java.util.*; 
public class FrequencyList
{
    static Integer[] a ={
      2, 1, 3, 4, 2, 2, 1, 1, 3, 1, 3, 4, 2, 1, 5, 2, 4, 1, 2, 4, 1
    }; 
    static ArrayList<Integer> set = new ArrayList<Integer>(); 
    static ArrayList<Integer> freq = new ArrayList<Integer>(); 
    
    public static void findFreq(Integer[] a){
        set.clear(); 
        freq.clear(); 
        for (int i=0; i<a.length; i++){
           int idx = set.indexOf(a[i]); 
           if (idx <0){
              set.add(a[i]); 
              freq.add(0); 
              idx = set.size()-1; 
            }
           freq.set(idx, freq.get(idx)+1); 
        }
    }
    
    public static void printLists(ArrayList<Integer> set, ArrayList<Integer> freq){
       for (int i=0; i<set.size(); i++){
          System.out.printf("<%d, %d>\n", set.get(i), freq.get(i)); 
        }
    }
    
    public static void main(String[] args){
       findFreq(a); 
       printLists(set, freq); 
    }
}
