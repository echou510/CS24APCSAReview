
import java.util.ArrayList; 
import java.util.Arrays; 

public class SelectionSort{
   public static ArrayList<Integer> selectionSort(ArrayList<Integer> alist){
        ArrayList<Integer> blist = new ArrayList<Integer>(); 
   
        while (alist.size() >0){
           int min = Integer.MAX_VALUE; 
           int minIndex=0; 
           for (int i=0; i<alist.size(); i++){
               if (alist.get(i)<min){
                   min = alist.get(i); 
                   minIndex = i; 
                }
            }
           blist.add(alist.remove(minIndex)); 
        }
        return blist; 
    }
    
   public static void main(String[] args){
       ArrayList<Integer> x = new ArrayList<Integer>(
           Arrays.asList(new Integer[]{5, 6, 7, 3, 2, 1, 9, 10, 13, 0})
       );
       System.out.println("Before Sorting:"+x); 
       x = selectionSort(x); 
       System.out.println("After  Sorting:"+x);
    }
}

