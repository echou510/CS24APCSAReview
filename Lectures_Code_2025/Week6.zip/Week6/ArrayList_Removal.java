import java.util.*; 
public class ArrayList_Removal
{
    public static ArrayList<Integer> alist = new ArrayList<Integer>(
      Arrays.asList(new Integer[]{3, 2, 4, 1, 6, 8, 5}) 
    ); 
    public static void wrongList(ArrayList<Integer> alist){
      for (int i=0; i<alist.size(); i++){
           if (alist.get(i) % 2==0) alist.remove(i); 
        }
    }
    
    public static void backwardTraversal(ArrayList<Integer> alist){
      for (int i=alist.size()-1; i>=0; i--){
           if (alist.get(i)%2==0) alist.remove(i);
        }
    }
    
    public static void forwardTraversalWithoutAdvancing(ArrayList<Integer> alist){
       for (int i=0; i<alist.size(); ){
          if (alist.get(i)%2==0) alist.remove(i); 
          else i++; 
        }
    }
    public static void main(){
       System.out.printf("alist before removal: %s\n", alist); 
       wrongList(alist);
       System.out.printf("alist after removal: %s\n", alist); 
       
       alist.clear(); 
       alist = new ArrayList<Integer>(
         Arrays.asList(new Integer[]{3, 2, 4, 1, 6, 8, 5}) 
       ); 
       System.out.printf("alist before backward traversal: %s\n", alist); 
       backwardTraversal(alist);
       System.out.printf("alist after backward traversal: %s\n", alist); 
       
       alist.clear(); 
       alist = new ArrayList<Integer>(
         Arrays.asList(new Integer[]{3, 2, 4, 1, 6, 8, 5}) 
       ); 
       System.out.printf("alist before forward no advancing traversal: %s\n", alist); 
       forwardTraversalWithoutAdvancing(alist);
       System.out.printf("alist after forward no advancing traversal: %s\n", alist); 
    }
}
