import java.util.*; 
public class DivingTeam
{
    public static Double[] diveList = {
       9.7, 9.2, 9.1, 9.8, 9.6, 9.4, 9.5, 9.9, 9.3, 10.0
    }; 
    
    public static ArrayList<Double> findMedalists(Double[] diveList){
       double gold = 0.0, silver = 0.0, bronze = 0.0;
       
       for (int i=0; i<diveList.length; i++){
           if (diveList[i] > gold){
              bronze = silver; 
              silver = gold; 
              gold = diveList[i]; 
            }
           else if (diveList[i] > silver){
               bronze = silver; 
               silver = diveList[i]; 
            }
           else if (diveList[i] > bronze){
               bronze = diveList[i]; 
            }
        }
       ArrayList<Double> medalist = new ArrayList<Double>(
         Arrays.asList(new Double[]{gold, silver, bronze})
       ); 
       return medalist; 
    }
    
    public static void main(String[] args){
       ArrayList<Double> medalists = findMedalists(diveList); 
       System.out.printf("Top 3 scores are %s\n", medalists); 
    }
}
