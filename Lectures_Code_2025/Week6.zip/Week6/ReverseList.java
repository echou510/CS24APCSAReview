import java.util.*; 
public class ReverseList
{
    static Integer[] a = {3, 5, 8, 1, 4}; 
    public static ArrayList<Integer> reverse(ArrayList<Integer> alist){
      int N = alist.size(); 
      ArrayList<Integer> blist = new ArrayList<Integer>(); 
      while (N>0){
           blist.add(0, alist.remove(0)); 
           N--; 
        }
      return blist; 
    }
    public static ArrayList<Integer> reverse2(ArrayList<Integer> alist){
      ArrayList<Integer> blist = new ArrayList<Integer>(); 
      for (int i=alist.size()-1; i>=0; i--){
           blist.add(alist.get(i)); 
        }
      return blist; 
    }
    public static void main(String[] args){
       ArrayList<Integer> alist = new ArrayList<Integer>(
         Arrays.asList(a) 
       ); 
       alist = reverse(alist);
       System.out.println(alist); 
       
       alist = reverse2(alist);
       System.out.println(alist); 
    }
}
