
public class Combination
{
    static String s = "ABCDE"; 
    
    public static void combination(String s){
      for (int i=0; i<s.length()-1; i++){
           for (int j=i+1; j<s.length(); j++){
               String x = ""+s.charAt(i)+s.charAt(j);
               System.out.println(x); 
            }
        }
    }
    
    public static void lowerTriangle(String s){
        for (int i=1; i<s.length(); i++){
          for (int j=0; j<i; j++){
              System.out.println(""+s.charAt(i)+s.charAt(j)); 
            }
        }
         
    }
    
    public static void main(String[] args){
       combination(s);
       
       System.out.println(); 
       lowerTriangle(s); 
    }
}
