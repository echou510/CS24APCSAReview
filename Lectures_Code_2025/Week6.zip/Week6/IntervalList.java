import java.util.*; 
public class IntervalList
{
    public static String data = "111222233444444556777777777888999AAABBBBBBBCCCCDDEEE";
    
    public static int longestRun(String data){
       ArrayList<Integer> cuts = new ArrayList<Integer>(); 
       
       cuts.add(0); 
       for (int i=0; i<data.length()-1; i++){
          if (data.charAt(i) != data.charAt(i+1)) cuts.add(i+1); 
        }
       cuts.add(data.length()); 
       System.out.println(cuts);
       int m = 0; 
       int idx =-1; 
       for (int i=0; i<cuts.size()-1; i++){
          int run = cuts.get(i+1)-cuts.get(i); 
          if (run > m){
              m = run; idx = cuts.get(i); 
            }
        }
       System.out.printf("%c has the longest run of %d\n", data.charAt(idx), m); 
       return m; 
    }
    
    public static void main(String[] args){
       int m = longestRun(data); 
       System.out.printf("Longest run is %d\n", m); 
    }
}
