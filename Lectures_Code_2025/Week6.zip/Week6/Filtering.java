import java.util.*; 
public class Filtering
{
    static Integer[] a = {1, 7, 2, 4, 3, 6, 8, 5, 9}; 
    public static ArrayList<Integer> getEven(ArrayList<Integer> alist){
        ArrayList<Integer> elist = new ArrayList<Integer>(); 
        
        for (Integer x: alist){
           if (x %2==0) elist.add(x); 
        }
        return elist; 
    }
    public static ArrayList<Integer> removeEven(ArrayList<Integer> alist){
        for (int i=0; i<alist.size(); ){
           if (alist.get(i)%2==0) alist.remove(i); 
           else i++; 
        }
        return alist; 
    }
    
        public static ArrayList<Integer> removeEven2(ArrayList<Integer> alist){
        for (int i=alist.size()-1; i>=0; i--){
           if (alist.get(i)%2==0) alist.remove(i); 
    
        }
        return alist; 
    }
    public static void main(String[] args){
       ArrayList<Integer> alist = new ArrayList<Integer>(
          Arrays.asList(a)  
       ); 
       ArrayList<Integer> evenList = getEven(alist); 
       System.out.println("Even List: "+evenList); 
       ArrayList<Integer> oddList = removeEven(alist); 
       System.out.println("Odd List: "+oddList); 
       
        ArrayList<Integer> blist = new ArrayList<Integer>(
          Arrays.asList(a)  
       ); 
       ArrayList<Integer> oddList2 = removeEven2(alist); 
       System.out.println("Odd List2: "+oddList2); 
    }
}
