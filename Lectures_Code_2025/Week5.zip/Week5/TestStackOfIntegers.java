
public class TestStackOfIntegers
{
   
   public static void main(String[] args){
     StackOfIntegers stack = new StackOfIntegers(); 
     for (int i=0; i<5; i++){
         stack.push(2*(i+1));
      }
     
     while (!stack.empty()){
         System.out.println(stack.pop());   
      }
    }
}
