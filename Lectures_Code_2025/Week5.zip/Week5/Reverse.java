import java.util.*; 
public class Reverse
{
    static int[] a = {1, 2, 3, 4, 5}; 
    static int[] b = {6, 7, 8, 9, 10}; 
    public static int[] reverse1(int[] a){
        int[] b = new int[a.length]; 
        for (int i=0; i<a.length; i++){
           b[a.length-1-i] = a[i]; 
        }
        return b; 
    }
    
    public static int[] reverse2(int[] a){
       for (int i=0; i<a.length/2; i++){
          int tmp = a[i]; 
          a[i] =a[a.length-1-i];
          a[a.length-1-i] = tmp;
        }
       return a; 
    }
    
    public static void main(String[] args){
      System.out.printf("revese a[]=%s\n", Arrays.toString(reverse1(a))); 
      System.out.printf("revese b[]=%s\n", Arrays.toString(reverse2(b))); 
    }
}
