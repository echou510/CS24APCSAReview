import java.util.*; 
public class Shuffle
{ 
    static int[] a = {1, 2, 3, 4, 5}; 
    static int[] b = {6, 7, 8, 9, 10}; 
    
    public static int[] shuffle(int[] a){
       for (int i=0; i<a.length; i++){
          int j = (int)(Math.random()*a.length); 
          int tmp = a[i]; 
          a[i] = a[j]; 
          a[j] = tmp; 
        }
       return a; 
    }
    
    public static int[] shuffle2(int[] b){
      for (int i=b.length-1; i>0; i--){
          int j= (int)(Math.random()*i); 
          int tmp = b[i];
          b[i] = b[j];
          b[j] = tmp; 
        }
      return b; 
    }
    public static void main(){
       System.out.printf("a[]=%s\n", Arrays.toString(shuffle(a))); 
       System.out.printf("b[]=%s\n", Arrays.toString(shuffle2(b)));
    }
}
