import java.util.Arrays; 
/**
 * Write a description of class CopyTo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CopyTo
{
  static int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9}; 
  static int[] b = {10, 11, 12};
  
  public static void copyTo(int[] source, int[] destination, int fromIndex){
      if (fromIndex+source.length > destination.length) return;  
      for (int i=0; i<source.length; i++){
           destination[fromIndex+i] = source[i]; 
        }
    }
    
  public static void main(String[] args){
      System.out.print("\f"); 
      System.out.println("Source="+Arrays.toString(b)); 
      System.out.println("Destination="+Arrays.toString(a)); 
      copyTo(b, a, 4); 
      System.out.println("Destination after copyTo="+Arrays.toString(a)); 
      copyTo(b, a, 8); 
      System.out.println("Destination after copyTo="+Arrays.toString(a)); 
    }
}