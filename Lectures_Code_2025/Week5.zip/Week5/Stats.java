
public class Stats
{
    static int[] a = {2, 5, 3, 1, 4}; 
    public static int sum(int[] a){
      int s = 0; 
      for (int i=0; i<a.length; i++) s += a[i]; 
      return s; 
    }
    
    public static int max1(int[] a){
      int m = Integer.MIN_VALUE; 
      for (int x: a){
          if (x>m) m = x; 
        }
      return m; 
    }
    
    public static int max2(int[] a){
       int m = a[0]; 
       for (int i=1; i<a.length; i++){
          if (a[i] > m) m = a[i];
        }
       return m; 
    }
    
    public static int min1(int[] a){
      int m = Integer.MAX_VALUE; 
      for (int x: a){
          if (x<m) m = x; 
        }
      return m; 
    }
    
    public static int min2(int[] a){
       int m = a[0]; 
       for (int i=1; i<a.length; i++){
          if (a[i] < m) m = a[i];
        }
       return m; 
    }
    public static void main(String[] args){
       System.out.printf("sum(a)=%s\n", sum(a)); 
       System.out.printf("max1(a)=%s\n", max1(a)); 
       System.out.printf("max2(a)=%s\n", max2(a)); 
       
       System.out.printf("min1(a)=%s\n", min1(a)); 
       System.out.printf("min2(a)=%s\n", min2(a)); 
    }
}
