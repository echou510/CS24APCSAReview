
/**
 * Write a description of class Histogram here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Histogram
{
    static String s = "abdjslkqiepqruqwoirafdafhdjznxadoauifqprqlsdjfhfhsdgajweyrw";
    
    public static int[] histogram(String s){
       int[] h = new int[26]; 
       for (char x : s.toCharArray()){
           h[x-'a']++; 
        }
       return h;
    }
    
    public static void main(String[] args){
        int[] h = histogram(s);
       for (char x = 'a'; x <= 'z'; x++){
           System.out.printf("%c, %d\n", x, h[x-'a']); 
        }
    }
}
