import java.util.*; 
public class Rotate
{
   static int[] a = {1, 2, 3, 4, 5}; 
   static int[] b = {6, 7, 8, 9, 10}; 
   public static int[] rotateLeft(int[] a){
      int tmp = a[0]; 
      for (int i=1; i<a.length; i++){
           a[i-1] = a[i]; 
        }
      a[a.length-1] = tmp;
      return a; 
    }
    
   public static int[] rotateRight(int[] b){
      int tmp = b[b.length-1]; 
      for (int i=b.length-2; i>=0; i--){
          b[i+1] = b[i];
        }
      
      b[0] = tmp; 
      return b; 
    }
   public static void main(String[] args){
       System.out.printf("rotate left a[]=%s\n", Arrays.toString(rotateLeft(a))); 
       System.out.printf("rotate right b[]=%s\n", Arrays.toString(rotateRight(b))); 
    }
}
