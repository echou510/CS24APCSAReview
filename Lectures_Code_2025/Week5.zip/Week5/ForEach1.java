
public class ForEach1
{
  public static void main(String[] args){
      String[] faceBookFriends = {"Jordan", "Jordin", "Jordyn"}; 
      for (String s: faceBookFriends){
          System.out.println(faceBookFriends);
        }
    }
}