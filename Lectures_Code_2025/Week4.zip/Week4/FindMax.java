
public class FindMax{
  static int[] ary = {3, 5, 8, 12, 4, 0, 1, -4, 9, 17}; 
  
  public static int findMax1(int[] ary){
      int max = Integer.MIN_VALUE; 
      for (int i=0; i<ary.length; i++){
          if (ary[i] >= max) max = ary[i]; 
        }
      return max; 
    }
    
  public static int findMax2(int[] ary){
      int max; 
      if (ary.length>0) max = ary[0];  else return Integer.MIN_VALUE; 
      for (int i=1; i<ary.length; i++){
          if (ary[i] >= max) max = ary[i]; 
        }
      return max; 
    }
    
  public static void main(String[] args){
      System.out.println(findMax1(ary)); 
      System.out.println(findMax2(ary)); 
    }
}
