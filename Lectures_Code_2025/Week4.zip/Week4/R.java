import java.util.Arrays; 
import java.util.ArrayList; 
/**
 * Write a description of class R here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class R
{
    public static void main(String[] args){
      ArrayList<String> slist = new ArrayList<String>(Arrays.asList(new String[]{
           "A", "B", "C"
        })); 
      Integer[] a = (Integer[]) new ArrayList<Integer>(Arrays.asList(new Integer[]{1, 2, 3})).toArray(); 
    }
}
