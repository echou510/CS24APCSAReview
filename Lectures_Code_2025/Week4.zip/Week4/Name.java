import java.util.Arrays;
public class Name implements Comparable<Name>{
    String n; 
    Name(String s){n =s; }
    public String getN(){ return n; }
    public int compareTo(Name other){
       if (getN().compareTo(other.getN()) >0 ) return 1; 
       else if (getN().compareTo(other.getN())<0) return -1; 
       return 0; 
    }
    public String toString(){ return n; }
    
    public static void main(String[] args){
       System.out.print("");
       Name[] nlist = {new Name("Eric"), new Name("Tom"),  new Name("Abel")}; 
       
       System.out.println(Arrays.toString(nlist)); 
       Arrays.sort(nlist); 
       System.out.println(Arrays.toString(nlist)); 
       
       for (int i=0; i<30; i++){
          int x = (int) (Math.random()*8)*3+3; 
          System.out.println(x); 
        }
       System.out.println("Java".substring(0, 0)); 
       System.out.println("a 1 b 203928049238 c 43u28 d 9993".replaceAll("\\d+", "*")); 
    }
    
}
