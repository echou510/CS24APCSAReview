import java.util.*; 
/**
 * Write a description of class GetPosition here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GetPosition
{
                             //012345678901234567890123456789012345678901
   public static String str = "ZNAAAhdlAAfjdaljAAAAAdkaj;fkdsAAAAdj;asfAA"; 
   
   public static ArrayList<Integer> getPos(String s, String pattern){
        ArrayList<Integer> plist = new ArrayList<Integer>(); 
        int pos = str.indexOf(pattern); 
        while (pos >=0){
           plist.add(pos); 
           pos = str.indexOf(pattern, pos+pattern.length()); 
        }
        return plist; 
    }
   
   public static void main(String[] args){
      System.out.println(getPos(str, "AA")); 
    }
}
