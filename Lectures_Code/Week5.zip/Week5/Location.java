import java.util.*; 
public class Location implements Comparable<Location>
{
    double x, y; 
    Location(double x, double y){this.x = x; this.y=y; }
    Location(){}
    public double getDistance(){ return Math.sqrt(x*x + y*y); }
    public int compareTo(Location that){
       int r;
       if      (getDistance() > that.getDistance()) r = 1; 
       else if (getDistance() < that.getDistance()) r = -1; 
       else                                         r =0; 
       return r; 
    }
    public String toString(){ 
        String xstr = String.format("%5.2f",x);
        String ystr = String.format("%5.2f",y); 
        return "("+xstr+", "+ystr+")"; 
    }
}


