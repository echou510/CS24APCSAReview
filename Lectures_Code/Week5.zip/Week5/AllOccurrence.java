import java.util.ArrayList; 
public class AllOccurrence{
    public static ArrayList<Integer> allOccurrence(String s, String p){
       ArrayList<Integer> ilist = new ArrayList<Integer>();    
       for (int i=0; i<s.length(); ){
           int index = s.indexOf(p, i); 
           if (index>=0){
               ilist.add(index);
               i = index + p.length(); 
            }
           else i=s.length(); 
        }
       return ilist; 
    }
    
    public static void main(String[] args){
      System.out.print("\f"); 
      String source = "Old MACDONALD had a farm. "+
      "E-I-E-I-O. And on his farm he had a cow. "+
      "E-I-E-I-O. With a moo moo here. And a moo moo there"+
      "Here a moo, there a moo. Everywhere a moo moo. "+
      "Old MacDonald had a farm. E-I-E-I-O"; 
      ArrayList<Integer> ilist = allOccurrence(source, "moo");
      System.out.println("Occurrence of moo="+ilist); 
      ilist = allOccurrence(source, "E-I-E-I-O");
      System.out.println("Occurrence of E-I-E-I-O="+ilist); 
    }
}
