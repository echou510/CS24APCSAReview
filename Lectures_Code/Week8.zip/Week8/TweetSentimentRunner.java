import java.util.ArrayList; 
public class TweetSentimentRunner{
   public static void main(String[] args){
       ArrayList<String> tweet = new ArrayList<String>(); 
       tweet.add("If");
       tweet.add("only");
       tweet.add("Bradley's");
       tweet.add("arm");
       tweet.add("was");
       tweet.add("longer");
       tweet.add("best");
       tweet.add("photo");
       tweet.add("ever");
       ArrayList<String> processedTweet = removeStopWords(tweet);
       System.out.println(processedTweet); 
    }
    
   public static ArrayList<String> removeStopWords(ArrayList<String> arr){ 
       ArrayList<String> a = new ArrayList<String>(); 
       
       for (String s: arr){ if (s.length()>3) a.add(s); }
       return a; 
    }
}


