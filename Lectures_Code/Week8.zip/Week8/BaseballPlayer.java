public class BaseballPlayer{
  private String name; 
  private int hits; 
  private int atBats; 
  BaseballPlayer(String n, int a, int h){ 
      name=n; hits=h; atBats=a; 
    }
  public String getName(){ return name; }
  public int getHits()   { return hits;}
  public int getAtBats() {return atBats; }
  public double getBattingAverage() { 
      /* implementation not shown */
      return (double) getHits()/getAtBats(); 
    }
}

