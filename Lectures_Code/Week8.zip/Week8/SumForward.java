public class SumForward
{
    public static int Sum(int n){
        if (n == 1) return 1;   // base case
        return Sum(n-1) + n ;   // recursive formula
    }  
    public static void main(String[] args){
       System.out.println(Sum(10)); 
    }
}




