
public class MatrixTranspose{
    static int[][] m={
      {1, 2, 3}, 
      {4, 5, 6}, 
      {7, 8, 9} 
    }; 
    public static void transpose(int[][] m){
        for (int i=1; i<m.length; i++){
          for (int j=0; j<i; j++){
               int tmp = m[i][j];
               m[i][j] = m[j][i];
               m[j][i] = tmp; 
            }
        }
    }
    public static void display(int[][] m){
       for (int i=0; i<m.length; i++){
            for (int j=0; j<m[i].length; j++){
               System.out.print(m[i][j]+" ");
            }
            System.out.println(); 
        }
    }
    public static void main(String[] args){
      System.out.println("\fBefore Transpose:"); 
      display(m); 
      transpose(m);
      System.out.println("\nAfter Transpose:"); 
      display(m); 
    }
}
