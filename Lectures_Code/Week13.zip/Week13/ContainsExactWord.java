
public class ContainsExactWord
{
  public static boolean containsExactWord(String str, String pattern){
      return str.equals(pattern) ||   // exact the same
             str.indexOf(pattern+" ") == 0 ||
            (str.indexOf(" "+pattern)+1)+pattern.length() == str.length() || // pattern at end
             str.indexOf(" "+pattern+" ")>=0;  // pattern at middle
    }
    
  public static void main(String[] args){
      System.out.print("\f"); 
      System.out.println(containsExactWord("A", "A")); 
      System.out.println(containsExactWord(" A", "A")); 
      System.out.println(containsExactWord("A ", "A")); 
      System.out.println(containsExactWord(" A ", "A")); 
      System.out.println(containsExactWord("ABAB", "A")); 
      System.out.println(containsExactWord(" AB", "A")); 
      System.out.println(containsExactWord("BA ", "A")); 
      System.out.println(containsExactWord(" ABA ", "A")); 
      System.out.println(containsExactWord("AB A AB", "A")); 
      System.out.println(containsExactWord("ABAB", "A")); 
    }
}
