public class Diverse
{
   static int[] a = {1, 13, 6, 3, 7, 3, 7, 9, 8, 4, 32};
   static int[] b = {9, 8, 11, 7, 4, 3};
   
   public static boolean isDiverse(int[] x){
       
       for (int i=1; i<x.length; i++){
          for (int j=0; j<i; j++){
               if (x[i]==x[j]) return false; 
            }
        }
       return true; 
    }
   
   public static void main(String[] args){
      System.out.println("isDiverse(a)="+isDiverse(a)); 
      System.out.println("isDiverse(b)="+isDiverse(b)); 
    }
}
