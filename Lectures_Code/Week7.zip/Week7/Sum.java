import java.util.Arrays; 
/**
 * Write a description of class Sum here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Sum
{
   public static void main(String[] args){
       int[] a = {1, 2, 3, 4, 5, 6, 7, 8}; 
       
       int sum=0; 
       for (int i=a.length-1; i>=0; i--){
           sum+= a[i]; 
        } 
       System.out.println(Arrays.toString(a)+"'s sum="+sum); 
    }
}
