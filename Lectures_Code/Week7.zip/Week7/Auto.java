class Auto{
    int maxSpeed;
    double weight; // float 32 bit floating point, double is double float 64 bits
    int noSeats;
    
    // Auto(){} 
}