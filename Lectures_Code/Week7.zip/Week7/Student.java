
/**
 * Write a description of class Student here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Student extends Person
{ 
    String address = ""; 
    Student(String a, String n){
        name = n; 
        address = a; 
    }
    public String toString(){
       return "S["+name+", "+address+"]"; 
    }
}
