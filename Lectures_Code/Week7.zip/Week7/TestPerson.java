
/**
 * Write a description of class TestPerson here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestPerson
{
    public static void main(String[] args){
      Student s = new Student("Tom", "1 First Street"); 
      Person p = new Person(); 
      p.name = "Nancy"; 
      Person[] plist = {p, s};
      
      for (Person x: plist) System.out.println(x); 
    }
}
