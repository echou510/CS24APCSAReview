
public class Swap0
{  
    public static void main(String[] args){
      int a =3;
      int b =5; 
      System.out.print("\f");
      System.out.println("Before swapping A="+a+"  B="+b);
      
      int tmp = a; 
      a = b; 
      b = tmp; 
      System.out.println("After swapping  A="+a+"  B="+b); 
    
    }
}
