public class LinearSearchC{
    static String[] greek = {
    "Alpha", "Beta", "Gamma", "Delta", "Epsilon	", "Zeta", "Eta", "Theta", 
    "Iota", "Kappa", "Lambda", "Mu", "Nu", "Xi", "Omicron", "Pi", 
    "Rho", "Sigma", "Tau	", "Upsilon", "Phi", "Chi", "Psi", "Omega"
    }; 
    
    public static int linearSearch(String[] list, String pattern){ 
      int index=-1;  boolean found = false; 
      for (int i=0; i<list.length && !found; i++){
            if (list[i].equals(pattern)) { index = i;  found = true; }
        }
      return index;  
    }

    public static void main(String[] args){
       System.out.println("Index of Xi is "+linearSearch(greek, "Xi")); 
       System.out.println("Index of Phi is "+linearSearch(greek, "Phi")); 
       System.out.println("Index of Ace is "+linearSearch(greek, "Ace"));
       System.out.println("Index of King is "+linearSearch(greek, "King")); 
    }
}


