import java.util.Arrays; 
public class ArrayForCopy
{
  static int[] original  = {23, 51, 14, 50};
  static int[] duplicate = new int[original.length]; 
  
  public static void main(String[] args){
        System.out.print("\f"); 
        for (int i=0; i<original.length; i++){
           duplicate[i] = original[i]; 
        }
        System.out.println("Original= "+Arrays.toString(original));   
        System.out.println("Duplicate="+Arrays.toString(duplicate));    
    }
}
