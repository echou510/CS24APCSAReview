public class Swap3<T>{
   T a; 
   T b; 
   Swap3(T x, T y){ a = x; b = y; }
   
   public void swap(){
      T tmp = a; 
      a = b; 
      b = tmp; 
    }
    
   static class Student {
      String name;
      Student(String n) {name = n; }
      public String toString(){ return name;}
    }
    
   static class Girl {
      String name;
      Girl(String n) {name = n; }
      public String toString(){ return name;}
    }
    
   public static void main(String[] args){
      Student a = new Student("Eric"); 
      Student b = new Student("Chou"); 
      System.out.print("\f");
      System.out.println("Before swapping A="+a+"  B="+b);
      Swap3 sw = new Swap3(a, b); 
      sw.swap(); 
      a = (Student) sw.a; 
      b = (Student) sw.b; 
      System.out.println("After swapping  A="+a+"  B="+b); 
      System.out.println("\n"); 
      Girl c = new Girl("Karen"); 
      Girl d = new Girl("Chen"); 
      System.out.println("Before swapping C="+c+"  D="+d);
      sw = new Swap3(c, d); 
      sw.swap(); 
      c = (Girl) sw.a; 
      d = (Girl) sw.b; 
      System.out.println("After swapping  C="+c+"  D="+d); 
    }
}
