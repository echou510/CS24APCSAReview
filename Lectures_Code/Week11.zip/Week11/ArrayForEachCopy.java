import java.util.Arrays; 
public class ArrayForEachCopy
{
  static int[] original  = {23, 51, 14, 50};
  static int[] duplicate = new int[original.length]; 
  
  public static void main(String[] args){
        System.out.print("\f"); 
        int i=0; 
        for (int a: original){
           duplicate[i++] = a; 
        }
        System.out.println("Original= "+Arrays.toString(original));   
        System.out.println("Duplicate="+Arrays.toString(duplicate));    
    }
}
