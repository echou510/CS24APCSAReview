public class FindMaxIndex2DCell{
    static int[][] m = {
      {3, 9, 21, 4}, 
      {11, 15, 13, 10}, 
      {6, 23, 8, 2}, 
      {17, 1, 0, 9}
    };
    static class Cell{
      int row, col; 
      Cell(int r, int c){ row=r; col=c; }
    }
    public static Cell findMaxIndex2D(int[][] m){
        Cell encodedIndex = new Cell(0, 0); 
        int max = Integer.MIN_VALUE; 
        for (int i=0; i<m.length; i++){
          for (int j=0; j<m[i].length; j++){
               if (max <m[i][j]) { max = m[i][j]; encodedIndex = new Cell(i, j);  }
            }
        }
        
        return encodedIndex; 
    }
    public static void main(String[] args){
      Cell index = findMaxIndex2D(m); 
      System.out.println("Max at index ("+(index.row)+", "+(index.col)+")"); 
    }
}


