public class FindMaxIndex2D{
    static int[][] m = {
      {3, 9, 21, 4}, 
      {11, 15, 13, 10}, 
      {6, 23, 8, 2}, 
      {17, 1, 0, 9}
    };
    public static int findMaxIndex2D(int[][] m){
        int encodedIndex = 0; 
        int max = Integer.MIN_VALUE; 
        for (int i=0; i<m.length; i++){
          for (int j=0; j<m[i].length; j++){
               if (max <m[i][j]) { max = m[i][j]; encodedIndex = i*m[0].length+j;  }
            }
        }
        
        return encodedIndex; 
    }
    public static void main(String[] args){
      int index = findMaxIndex2D(m); 
      System.out.println("Max at index ("+(index/m[0].length)+", "+(index%m[0].length)+")"); 
    }
}


