public class Swap1
{   
    public static void main(){
      int a =3;
      int b =5; 
      System.out.print("\f");
      System.out.println("Before swapping A="+a+"  B="+b);
      
      Integer A = new Integer(a); 
      Integer B = new Integer(b); 
      a = B; 
      b = A; 
      System.out.println("After swapping  A="+a+"  B="+b); 
    }
}
