public class SwapWrong
{
    public static void swap(Integer x, Integer y){
        Integer tmp = x; 
        x = y; 
        y = tmp; 
        System.out.println("Inside swapping A="+x+"  B="+y); 
    }
    public static void main(String[] args){
      Integer a =3;
      Integer b =5; 
      System.out.print("\f");
      System.out.println("Before swapping A="+a+"  B="+b);
      
      swap(a, b); 
      System.out.println("After swapping  A="+a+"  B="+b); 
    
    }
}


