import java.util.Arrays; 
public class OneDToTwoD{
    static int[] D  = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9}; 
    static int[][] DD = new int[3][4];
    public static void copy(int[] a, int[][] m){
      boolean end=false; 
      int p=0; 
      for (int i=0; i<m.length&&!end; i++){
           for (int j=0; j<m[i].length&&!end; j++){
              if (p<a.length) m[i][j] = a[p++]; 
              else end=true; 
            }
        }
    }
    public static void print2D(int[][] m){
      for (int i=0; i<m.length; i++){
           for (int j=0; j<m[i].length; j++){
              System.out.printf("%3d ", m[i][j]); 
            }
           System.out.println(); 
        }
    }
    public static void main(){
       System.out.print("\f");
       System.out.println("1D Array = "+Arrays.toString(D));
       copy(D, DD); 
       System.out.println("2D Array :"); 
       print2D(DD); 
    }
}
