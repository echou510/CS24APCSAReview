import java.util.Arrays; 
public class TwoDToOneD{
    static int[] D  = new int[10]; 
    static int[][] DD1 = {
     {1, 2, 3}, 
     {4, 5, 6}, 
     {7, 8, 9}
    };
    static int[][] DD2 = {
     {1, 2, 3, 4, 5}, 
     {6, 7, 8, 9, 10}, 
     {11, 12, 13, 14, 15}
    };  
    public static void reset(int[] a){ 
        for (int i=0; i<a.length; i++) a[i]=0; 
    }
    public static void copy(int[][] m, int[] a){
      boolean end=false; 
      int p=0; 
      for (int i=0; i<m.length&&!end; i++){
           for (int j=0; j<m[i].length&&!end; j++){
              if (p<a.length) a[p++] = m[i][j]; 
              else end=true; 
            }
        }
    }
    public static void print2D(int[][] m){
      for (int i=0; i<m.length; i++){
           for (int j=0; j<m[i].length; j++){
              System.out.printf("%3d ", m[i][j]); 
            }
           System.out.println(); 
        }
    } 
    public static void main(){
       System.out.print("\f");
       System.out.println("2D Array DD1:"); 
       print2D(DD1); 
       copy(DD1, D); 
       System.out.println("1D Array = "+Arrays.toString(D));
       reset(D); 
       System.out.println(); 
       System.out.println("2D Array DD2:"); 
       print2D(DD2); 
       copy(DD2, D); 
       System.out.println("1D Array = "+Arrays.toString(D));

    }
    

}
