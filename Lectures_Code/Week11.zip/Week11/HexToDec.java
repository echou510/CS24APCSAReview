public class HexToDec{
  static String hex = "AB3E";   
  public static int hexToDecimal(String h){
       int decimal = 0; 
       for (int i=0; i<h.length(); i++){
           int d =0; 
           switch (h.charAt(i)){
              case '0':  d=0; break; 
              case '1':  d=1; break; 
              case '2':  d=2; break; 
              case '3':  d=3; break; 
              case '4':  d=4; break; 
              case '5':  d=5; break; 
              case '6':  d=6; break; 
              case '7':  d=7; break; 
              case '8':  d=8; break; 
              case '9':  d=9; break; 
              case 'A':  d=10; break; 
              case 'B':  d=11; break; 
              case 'C':  d=12; break; 
              case 'D':  d=13; break; 
              case 'E':  d=14; break; 
              case 'F':  d=15; break; 
            }
           decimal = decimal * 16 + d; 
        }
       return decimal; 
    }
  public static void main(String[] args){
      System.out.println("Decimal value of "+hex+" is "+hexToDecimal(hex)); 
    }
}
