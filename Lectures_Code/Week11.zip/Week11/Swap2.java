public class Swap2{
   int a; 
   int b; 
   Swap2(int x, int y){ a = x; b = y; }
   public void swap(){
      int tmp = a; 
      a = b; 
      b = tmp; 
    }
   public static void main(String[] args){
      int a =3;
      int b =5; 
      System.out.print("\f");
      System.out.println("Before swapping A="+a+"  B="+b);
      Swap2 sw = new Swap2(a, b); 
      sw.swap(); 
      a = sw.a; 
      b = sw.b; 
      System.out.println("After swapping  A="+a+"  B="+b); 
    }
}


