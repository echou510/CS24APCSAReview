import java.util.ArrayList; 
import java.util.Arrays; 
public class Conversion
{
  static String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  static char[] alpha = getChars(alphabet);
  static ArrayList<String> alphaList = new ArrayList<String>(); 
  
  public static char[] getChars(String x){
      char[] a = new char[x.length()];
      for (int i=0; i<x.length(); i++) a[i]= x.charAt(i); 
      return a; 
    } 
  public static ArrayList<String> getList(String x){
      ArrayList<String> a = new ArrayList<String>(); 
      for (int i=0; i<x.length(); i++){
          a.add(x.substring(i, i+1)); 
        }
      return a; 
    }
  public static String reverseToString(char[] x){
      String str = ""; 
      for (int i=x.length-1; i>=0; i--){
          str += ""+x[i]; 
        }
       return str; 
    }
  public static String reverseToString(ArrayList<String> x){
      String str = ""; 
      for (int i=x.size()-1; i>=0; i--){
          str += ""+x.get(i); 
        }
       return str; 
    }
  public static void main(String[] args){
       alphaList = getList(alphabet);  
       System.out.print("\f");
       System.out.println(alphabet);
       System.out.println(Arrays.toString(alpha));
       System.out.println(reverseToString(alpha)); 
       System.out.println(alphaList); 
       System.out.println(reverseToString(alphaList)); 
    }
}
