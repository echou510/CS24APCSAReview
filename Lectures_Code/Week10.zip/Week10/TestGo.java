public class TestGo
{
    public static String B = Go.B; 
    public static String W = Go.W; 
    public static String S = Go.S; 
    public static String[][] gameboard = Go.gameboard; 
    public static void display(String[][] m){
       System.out.println("  0 1 2 3 4 5 6 7 8");
       for (int i=0; i<m.length; i++){
            System.out.print(i+" ");
            for (int j=0; j<m[i].length; j++){
               System.out.print(m[i][j]+" ");
            }
            System.out.println(); 
        }
    }
    public static void display(int[][] m){
       System.out.println("  0 1 2 3 4 5 6 7 8");
       for (int i=0; i<m.length; i++){
            System.out.print(i+" ");
            for (int j=0; j<m[i].length; j++){
               System.out.print(m[i][j]+" ");
            }
            System.out.println(); 
        }
    }
    public static int[][] getDeadMap(String[][] m){
        int[][] n= new int[m.length][m.length];
        for (int i=0; i<m.length; i++){
          for (int j=0; j<m.length; j++){
              if (Go.isDead(m, i, j)) n[i][j] = 1; 
              else n[i][j]=0; 
            }
        }
        return n; 
    }
    
    public static void main(String[] args){
      System.out.println("\fGame Board:"); 
      display(gameboard);
      System.out.println(); 
      System.out.println("Dead Map:"); 
      int[][] n = getDeadMap(gameboard);
      display(n); 
    }
}
