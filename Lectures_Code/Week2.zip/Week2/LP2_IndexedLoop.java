
public class LP2_IndexedLoop
{
   public static void main(String[] args){
       System.out.print("\f"); 
       for (int i=1; i<10; i++){
           System.out.print(i+" ");           
        }
       System.out.println(); 
    }
}
