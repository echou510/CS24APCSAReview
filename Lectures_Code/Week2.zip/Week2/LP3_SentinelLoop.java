
public class LP3_SentinelLoop
{                       
    static String str = "Welcome to Java and Love Programming in Java"; 
    
    public static int search(String s, char c){
       int index = -1;  // default return value if not found in search
       boolean found = false; // sentinel
       int i=0; 
       while (!found && i<s.length()){ // && i<s.length() 
          if (s.charAt(i)==c) {
              index = i; 
              found = true; 
            }
          i++; 
        }
       
       return index; 
    }
    
    public static void main(String[] args){
       System.out.print("\f"); 
       System.out.println("e's index is "+search(str, 'a')); 
     }
}
