import java.util.Arrays; 
public class MergeArray
{
   public static int[] mergeArray(int[] a1, int[] a2){
       int[] a3 = new int[a1.length+a2.length];
       int p1=0, p2=0, p3=0; 
       while (p1<a1.length && p2<a2.length){
           if (a1[p1]<=a2[p2]) a3[p3++]=a1[p1++]; 
                          else a3[p3++]=a2[p2++]; 
        }
       while (p1<a1.length){a3[p3++] = a1[p1++];}
       while (p2<a2.length){a3[p3++] = a2[p2++];}
        
       return a3; 
    }
   public static void main(String[] args){
      int[] ary1 = {1, 3, 3, 5, 7, 9, 12, 23}; 
      int[] ary2 = {2, 2, 4, 8, 10, 14, 16, 18}; 
      System.out.println(Arrays.toString(ary1)); 
      System.out.println(Arrays.toString(ary2)); 
      System.out.println(Arrays.toString(mergeArray(ary1, ary2))); 
    }
}
