
public class LP6_NestedLoop
{
 public static void main(){
    System.out.print("\f");
     for (int i=1; i<10; i++){   // with i, j as the 2D coordinates. 
      for (int j=1; j<10; j++){ // one text cell
         if ((i==j || i+j==10)) System.out.printf("%1s ", "*");  
         else                   System.out.printf("%1s ", " "); 
        } // end of j
      System.out.println(); // change for a new line after finishing all cells in a row. 
    } // end of i 
  }
}
