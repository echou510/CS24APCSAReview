public class ShortCircuit{
  public static void main(String[] argv) {
    int denom = 0;
    int num = 3;
    if (denom != 0 && num / denom > 10) {
      System.out.println("Here");
    } else {
      System.out.println("There");
    }
  }
}