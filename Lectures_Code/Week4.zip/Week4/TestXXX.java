public class TestXXX{
  public static void main(String[] args){
       System.out.print("\f"); 
       System.out.println(XXX.count); // ClassName.count
       XXX x1 = new XXX(); 
       System.out.println(x1.count); 
        XXX x2 = new XXX(); 
       System.out.println(x1.count); 
        XXX x3 = new XXX(); 
       System.out.println(x1.count); 
        XXX x4 = new XXX(); 
       System.out.println(x1.count); 
        XXX x5 = new XXX(); 
       System.out.println(XXX.count); 
        XXX x6 = new XXX(); 
       System.out.println(x6.count); 
    }
}
