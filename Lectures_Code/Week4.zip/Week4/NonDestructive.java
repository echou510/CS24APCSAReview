public class NonDestructive{
    public static void main(String[] args){
      String[] myFavoriteThings = {"Memes", "Vines", "Snapchat"}; 
      
      for (String s: myFavoriteThings){
          System.out.println(s); 
        }
      
        String[] watchThis = yeah(myFavoriteThings); 
        for (String s: watchThis){
          System.out.println(s); 
        }
    }
    
    public static String[] yeah(String[] arr){
       String[] temp = new String[arr.length];
       
       for (int i=0; i<arr.length; i++){
           temp[i] = arr[i]; 
        }
       for (int i=0; i<temp.length; i++){
          temp[i] = "Fearless Pandas"; 
        }
       return temp; 
    }
}
