public class Laptop implements NetflixPlayer{
  public String play() { return "Pressed play on a Laptop."; }
  public String pause() { return "Pressed pause on a Laptop."; }
  public String rewind() { return "Pressed rewind on a Laptop."; }
}

