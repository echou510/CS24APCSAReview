public class Baby extends FamilyPerson{
    public String eat() { return "hands"; }
}
