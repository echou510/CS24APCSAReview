public class SmartPhone implements NetflixPlayer{
  public String play() { return "Pressed play on a SmartPhone."; }
  public String pause() { return "Pressed pause on a SmartPhone."; }
  public String rewind() { return "Pressed rewind on a SmartPhone."; }
}
