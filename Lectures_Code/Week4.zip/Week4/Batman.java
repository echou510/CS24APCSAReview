public class Batman
{
   public static void main(String[] args){
      Batman m1 = new Batman("Batman");
      m1.doSomeThing(); 

      Batman m2 = new Batman("CatWomen");
      m2.doSomeThing();  
    }
    
    private String name; 
    public Batman(String name){
       this.name = name; 
    }
    
    public String getName(){ return name; }
    public void doSomeThing(){ nowDoSomethingWith(this); }
    public void nowDoSomethingWith(Batman myObject){
      System.out.println("I am "+myObject.getName()); 
    }
}
