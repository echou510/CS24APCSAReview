public class Student{
   private String firstName; 
   private String lastName; 
   private int age; 
   public Student(){}
   public Student(String first){
       firstName = first; 
    }
   public Student(String first, String last){
       firstName = first; 
       lastName  = last;
    }
   public Student(String first, String last, int yearsold){
       firstName = first; 
       lastName  = last; 
       age       = yearsold; 
    }
}
