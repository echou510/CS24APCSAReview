public class Baby3 extends FamilyPerson{
  public String throwTantrum(){ return "scream loudly"; }
  public static void main(String[] args){
       Baby3 junior            = new Baby3(); 
       FamilyPerson babyCousin = new Baby3(); 
       System.out.println(junior.throwTantrum());
       System.out.println(babyCousin.throwTantrum()); 
       //System.out.println(((Baby3) babyCousin).throwTantrum()); 
    }
}
