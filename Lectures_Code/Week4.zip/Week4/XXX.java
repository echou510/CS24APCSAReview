import java.util.Scanner; 
public class XXX{
   static int count =0; 
   XXX(){count++; }
   public static void main(String[] args){
       Scanner input = new Scanner(System.in);
       
       System.out.print("\fEnter a Number: "); 
       int x = input.nextInt(); 
       System.out.println(x); 
       input.nextLine(); 
       System.out.print("Enter a Number: ");   
       int y=0;
       boolean done = false; 
       while (!done){
         try {
           y = Integer.parseInt(input.nextLine());  // convert string to integer
           done = true; 
         }
         catch(Exception e){
          }
        }
       System.out.println(y); 
    }
}
