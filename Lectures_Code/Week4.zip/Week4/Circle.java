public class Circle{
  double radius = 10.0;   
  Circle(double r){  // constructor 
      radius = r; 
    }
  public double getArea(){
      return Math.PI * radius * radius; 
    }  
  public double getPerimeter(){
      return 2*Math.PI*radius; 
    }
  public double getRadius(){ return radius; } 
  public void   setRadius(double r){ radius = r; }
  public String toString(){ return "Cirle[r="+radius+"]";}
  public static void main(String[] args){
      Circle circle = new Circle(5.0); 
      System.out.println(circle); 
    }
}
