import java.util.ArrayList; 
import java.util.List; 
public class NetflixPlayerTester{
 public static void main(String[] args){
     NetflixPlayer device1 = new SmartPhone(); 
     NetflixPlayer device2 = new Laptop(); 
     List<NetflixPlayer> devices = new ArrayList<NetflixPlayer>(); 
     devices.add(device1);
     devices.add(device2); 
     for (NetflixPlayer device: devices){
           System.out.println(device.play());
           System.out.println(device.pause()); 
           System.out.println(device.rewind());
           System.out.println(); 
        }
  }
}

