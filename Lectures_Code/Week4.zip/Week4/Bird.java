public class Bird extends GameCharacter{
  public String move(){  return "I fly"; }
}
