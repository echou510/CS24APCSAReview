public class Dog extends Mammal{
   String name; 
   public Dog(){
       super(); 
    }
   public Dog(String hairColor, String nameOfDog){
       super(hairColor);
       name = nameOfDog; 
    }
   public String getName(){ return name; }
   public static void main(String[] args){
       Dog myDog1 = new Dog(); 
       System.out.println(myDog1.getName()); 
       System.out.println(myDog1.getHairColor()); 
       System.out.println(myDog1.isVertebrate()); 
       System.out.println(myDog1.isMilkProducer()); 
       Dog myDog2 = new Dog("Brown", "Bella"); 
       System.out.println(myDog2.getName()); 
       System.out.println(myDog2.getHairColor()); 
       System.out.println(myDog2.isVertebrate()); 
       System.out.println(myDog2.isMilkProducer()); 
    }
}


