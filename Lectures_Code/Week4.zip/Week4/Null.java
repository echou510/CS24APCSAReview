public class Null{ 
  static Circle circle2; 
  public static void main(String[] args){
      Circle circle1 = new Circle(10);
      // book is buggy here.
      // Circle circle2; 
      
      System.out.println(doANullCheck(circle1)); 
      System.out.println(doANullCheck(circle2)); 
    }
    
  public static double doANullCheck(Circle c){
       if (c != null){
           return c.getArea(); 
        }
       else {
           return -1; 
        }
    }
}


