public class Baby2 extends FamilyPerson {
  private int age; 
  public Baby2(int myAge){ age = myAge; }
  public String eat(){
      if (age > 3) return "hands or a " + super.eat(); 
      else return "hands"; 
    }
  public static void main(String[] args){
       Baby2 youngBaby = new Baby2(2); 
       Baby2 oldBaby   = new Baby2(4); 
       System.out.println(youngBaby.eat());
       System.out.println(oldBaby.eat()); 
    }
}
