public class SporkUser extends FamilyPerson{
   public String eat(){ return "spork"; }
   public static void main(String[] args){
    }
}
