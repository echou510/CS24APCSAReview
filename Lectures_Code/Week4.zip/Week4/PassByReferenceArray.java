public class PassByReferenceArray
{
    public static void main(String[] args){
      String[] myFavoriteThings = {"Memes", "Vines", "Snapchat"}; 
      
      whoops(myFavoriteThings);
      for (String s: myFavoriteThings){
          System.out.println(s); 
        }
    }
    
    public static void whoops(String[] arr){
      for (int i=0; i<arr.length; i++){
          arr[i] = "Fearless Pandas"; 
        }
    }
}

