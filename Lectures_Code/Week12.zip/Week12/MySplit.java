import java.util.ArrayList; 
import java.util.Arrays; 
public class MySplit
{
   private static String str1 = "    AAA  BB  CC D  EEEEEE FFFF "; 
   private static String str2 = "AAA  BB  CC D  EEEEEE"; 
   private static String str3 = "AAA  BB  CC D  EEEEEE  "; 
   private static String str4 = "  AAA  BB  CC D  EEEEEE"; 
   private static String str5 = ""; 
   private static String str6 = "A"; 
   private String str=""; 
   MySplit(String s){str = s; }
   public String[] split(){
       ArrayList<String> a = new ArrayList<String>(); 
       if (str.length()==0) return null; 
       if (str.length()==1) return new String[]{str}; 
       str = str.trim(); 
       int i=0; 
       boolean isSpace = true;  
       String words = ""; 
       while (i<str.length()){
          if (isSpace && !str.substring(i, i+1).equals(" ")) {
                words+=str.substring(i, i+1);
                isSpace = !isSpace; 
            }
          else if (!isSpace && !str.substring(i,i+1).equals(" ")){
               words+=str.substring(i, i+1); 
            }
          else if (!isSpace && str.substring(i,i+1).equals(" ")){
               a.add(words); 
               words="";
               isSpace = !isSpace; 
            }
          i++; 
          if (i==str.length() && words.length() !=0) a.add(words);  
        }
       String[] b = new String[a.size()];
       for (int k=0; k<a.size(); k++) b[k]=a.get(k); 
       return b; 
    }
    
    public static void main(String[] args){
        MySplit m1 = new MySplit(str1);
        System.out.println(Arrays.toString(m1.split())); 
        MySplit m2 = new MySplit(str2);
        System.out.println(Arrays.toString(m2.split())); 
        MySplit m3 = new MySplit(str3);
        System.out.println(Arrays.toString(m3.split())); 
        MySplit m4 = new MySplit(str4);
        System.out.println(Arrays.toString(m4.split())); 
        MySplit m5 = new MySplit(str5);
        System.out.println(Arrays.toString(m5.split())); 
        MySplit m6 = new MySplit(str6);
        System.out.println(Arrays.toString(m6.split())); 
    }
}
