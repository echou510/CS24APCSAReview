
public class TestReaderHead
{
  public static int[] data = {10, 20, 30, 40, 50}; 
  public static void main(String[] args){
     ReaderHead r = new ReaderHead(data.length); 
     System.out.print("\f");
     System.out.println("B1 Part(a):"); 
     for (int i=0; i<data.length*3; i++){
         System.out.println("Index "+r.getIndex()+": "+data[r.getIndex()]); 
         r.next(); 
         if (i%data.length==data.length-1) System.out.println(); 
      }
      System.out.println("B1 Part(b):"); 
      r.reset(); 
      r.move(3); 
      System.out.println("Index "+r.getIndex()+": "+data[r.getIndex()]); 
      r.move(3); 
      System.out.println("Index "+r.getIndex()+": "+data[r.getIndex()]); 
      r.changeDirection(); 
      r.move(3); 
      System.out.println("Index "+r.getIndex()+": "+data[r.getIndex()]); 
      r.move(3); 
      System.out.println("Index "+r.getIndex()+": "+data[r.getIndex()]); 
    }
}
