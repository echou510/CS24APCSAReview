import java.util.ArrayList; 
public class WordList
{
  static String str = "A B C A B C D E F F A B C W S Z K Z";
  
  public static void main(String[] args){
       ArrayList<String> wlist = new ArrayList<String>(); 
       String[] tokens = str.split(""); 
       for (int i=0; i<tokens.length; i++) {
          tokens[i] = tokens[i].trim(); 
          if (tokens[i].length() !=0 && !wlist.contains(tokens[i])) wlist.add(tokens[i]); 
        }
       int[] wCount = new int[wlist.size()]; 
       for (int i=0; i<tokens.length; i++){
           for (int j=0; j<wlist.size(); j++){
               if (wlist.get(j).equals(tokens[i])) wCount[j]++; 
            }
        }
       System.out.print("\f");
       System.out.println("Original String="+str); 
       System.out.println("Non-recurring Set="+wlist); 
       for (int i=0; i<wlist.size(); i++){
          System.out.println(String.format("Word(%d)=",i)+wlist.get(i)+" happens "+wCount[i]+" times."); 
        }
    }
}
