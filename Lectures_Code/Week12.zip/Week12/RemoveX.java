import java.util.ArrayList; 
import java.util.Arrays; 
import java.util.List; 
public class RemoveX
{
   public static Integer[] alist; 
   public static void main(){
       alist = new Integer[]{9, 4, 3, 5, 6, 1, 2}; 
       ArrayList<Integer> al = 
           new ArrayList<Integer>(Arrays.asList(alist)); 
       System.out.println(al.remove(4));
       System.out.println(al); 
       System.out.println(new Integer(4)); 
       System.out.println(al); 
       System.out.println(al.set(4, 10));
       System.out.println(al); 
       List<String> students = new ArrayList<String>(); 
       students.add("A"); 
       students.add("B");
       students.add("C");
       for (int k=0; k<students.size(); k++) 
          System.out.print(students.set(k, "A")+" "); 
       System.out.println();
       for (String s: students)System.out.print(s+" "); 
              System.out.println(); 
    }
}
/*

*/