
/**
 * Write a description of class Toggler here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Toggler
{
  int state = -1;
  int count = 2; 
  Toggler(int count){ this.count = count; }
  
  public int toggle(){ state = (state+1) % count; return state; }
  
  
  public static void main(String[] args){
      System.out.println("\fPart (a) 3-way Toggle:"); 
      Toggler t = new Toggler(3); 
      for (int i=0; i<10; i++){
           System.out.println(t.toggle()); 
        }
      int count = 4;
      int step  = 2; 
      int base  = 10; 
      System.out.println("Part(b) 4-way Toggle: 10, 12, 14, 16 Toggle."); 
      Toggler t1 = new Toggler(count); 
      for (int i=0; i<10; i++){
           System.out.println((t1.toggle()*step+base)); 
        }
    }
}
